# Codex handoff — Fe₂S₂ CAS(30e,20o) correlation-guided TrimCI and AFQMC

**Date:** 2026-11-23  
**Purpose:** Transfer the scientifically relevant context from a long Korean ChatGPT research discussion to a separate Codex CLI session. This is a curated handoff, **not a verbatim export of the entire ChatGPT conversation**.

## 0. Instructions to Codex

1. Read this file, `Fe2S2_trial_design/README.md`, `Fe2S2_trial_design/MANIFEST.json`, and `Fe2S2_trial_design/fe2s2_model_v2/README_ko.md` **before editing code**.
2. Inspect the *existing* TrimCI, SAFIRE, Fe–S and Hubbard repositories, already-running calculations and input files. Reuse them where possible; do not invent paths, settings, or results.
3. Treat conclusions marked **validated** versus **preliminary/not yet tested** differently. Do not present numerical results as AFQMC improvements unless AFQMC was actually run with that trial.
4. For molecular benchmarks, retain the **complete supplied CAS Hamiltonian**. The `D` operators below are state classifiers or trial-design penalties, not a replacement for the integrals.
5. Use a separate branch/worktree and output folder; do not overwrite ongoing Hubbard AFQMC runs. Report calculations, exact input metadata, resources, numerical errors and scientific limitations.
6. First reproduce package self-tests, then integrate the objective into grow→optimize→trim; do not jump directly to expensive 4Fe4S production.

## 1. Research goal and prior Hubbard context

Long-term goal: formulate general methods for **AFQMC trial wavefunction generation** guided by local correlations and error decomposition, first in the Hubbard model and then in Fe₂S₂ / Fe₄S₄ molecules. The user is interested in *state-of-the-art-comparable* calculations, but recognizes that minimizing trial variational energy does not always minimize phaseless AFQMC bias.

Hubbard precedent:
- Use a standing-wave TrimCI trial of M selected determinants. Grow determinants, optimize coefficients, trim, repeat.
- Doublon number `D=Σ_i n_{i↑}n_{i↓}` partitions site-occupation configurations.
- Two optimization concepts are distinct: (i) improve the **direction within a physically important low-D subspace**, (ii) optimize **relative weight of different D sectors** with Gutzwiller `g^D` or sector-specific Ritz.
- In Hubbard tests, projected low-sector Ritz can improve sector quality, but a direct projection back to a fixed M standing-wave determinant representation can lose the desired sector structure. Gutzwiller requires a correlated trial evaluator rather than simply changing M coefficients.
- AFQMC bias decomposition: compare sector-parallel and orthogonal error contributions and their *cancellation*. Variational-energy improvement or sector-fidelity improvement does not guarantee phaseless AFQMC improvement. A production AFQMC energy estimator and a coherent proxy/error decomposition are **not automatically identical**.
- Ongoing separate Hubbard AFQMC work is debugging walker-adaptive MH/Gutzwiller sampling, ratio/force-bias errors and population control. Do not assume that code is production-validated just because some one-step tests passed.

Proposed new algorithm: at *each* TrimCI iteration, **expand** by Hamiltonian connectivity, then **optimize** selected-space coefficients using the exact Hamiltonian plus physically motivated penalties, then **trim** with a controlled determinant budget. After growing the subspace, optionally optimize sector weights with a distinct correlator, and finally evaluate trial quality in AFQMC. Compare same budget, basis, spin and Hamiltonian across variants.

## 2. Exact input model and provenance

Target: oxidized `[Fe₂S₂(SCH₃)₄]²⁻`, singlet, CAS(30 electrons, 20 spatial orbitals). Source: Li–Chan Fe–S active-space model, `Fe2S2_trial_design/fe2s2_model_v2/FCIDUMP`. The supplied active-space Hamiltonian and orbital numbering must be checked; no external integral reconstruction is necessary for the first experiments.

1-based orbital groups in supplied ordering:
- Fe A: `[3,4,5,6,7]`
- Fe B: `[14,15,16,17,18]`
- Ligand-related L: `[1,2,8,9,10,11,12,13,19,20]`

Reference active-space DMRG energy: `−116.60560910 Ha` (verify alignment of electron/spin/orbital conventions in any independent comparison). FCIDUMP ECORE = 0. The Hamiltonian is exact **within the chosen nonrelativistic active-space model**; it is not the full all-electron physical molecule.

FCIDUMP checksum (SHA-256): `95d8786af06eeea2107e19ffd98c66a6ca97fc8c9864175a4f6d64512b6f2df9`.

## 3. Physical interaction analysis: why one global doublon penalty is insufficient

Validated integral statistics on 5d sets (means, eV):
- Fe A same-orbital U `21.8887`; Fe B `21.8861`.
- Fe A distinct-orbital direct Coulomb V `20.3088`; Fe B `20.3080`.
- Fe A Hund J `0.7525`; Fe B `0.7531`.
- Direct Coulomb between Fe groups ~`5.14993` eV.
These are **bare active-space integrals**, NOT screened Hubbard U or excitation energies.

From previously computed restricted charge blocks: `(5,5,20) → (6,4,20)` costs ~`16.6492 eV`, `(4,6,20)` ~`16.7277 eV` within the closed-ligand block. In contrast, a restricted variational state in `(6,5,19)` has energy ~`2.9651 eV` **below** the closed-ligand `(5,5,20)` ionic reference. The latter is only a variational upper bound for that sector, not a spectroscopic energy. Do not penalize ligand→Fe transfer blindly. At the ionic high-spin reference, a residual projection analysis found strong one-ligand-hole coupling (~97.626% of squared residual), Fe→Fe single charge transfer ~2.061% of squared residual; these are not wavefunction probabilities.

Local spin energy costs computed under a *specified ionic mean-field embedding* include `d5 S=5/2→3/2` about `2.42 eV` and `d6 S=2→1` about `2.44 eV`. Different embedding changes d5 cost markedly (~0.72–0.76 eV). Therefore spin costs are **embedding-dependent diagnostics**, not universal local Hund constants or molecular spin gaps.

## 4. Proposed generalized correlation operators

Define `N_I = Σ_{p in I,σ} n_{pσ}` and local `S_I²`, with `I=A,B`. Joint charge sectors are `(N_A,N_B,N_L)` with sum 30, possibly refined by local spin `(S_A,S_B)` while preserving molecular total spin S=0.

### 4a. Hole doublon (empty orbital count)

Since 30 electrons occupy 20 spatial orbitals, ordinary electron doublon number has minimum 10. Define:

`D_empty = Σ_{p=1}^{20} (1−n_{p↑})(1−n_{p↓}) = D_electron − 10 ≥ 0`.

Candidate meaningful sector coordinate: can admit some ligand→Fe redistribution at zero empty count while distinguishing Fe-site electron depletion. **Not validated as a complete low-energy subspace classifier.** Orbital-basis-dependent.

### 4b. Local Hund/spin penalty

`D_Hund = Σ_{I=A,B}[Smax(N_I)(Smax(N_I)+1)−S_I²]`, `Smax(n)=min(n,10−n)/2`.

More physically calibrated option, using computed local spin-resolved eigenenergies:

`C_spin = Σ_{I,N,S}[ε_{I,min}(N,S)−ε_{I,min}(N)] P_{I,N,S}`.

`trial_operators.py` evaluates the corresponding selected-determinant-space spin penalty, using local spin projectors *before restriction to the truncated selected space* (important if spin completeness is imperfect).

Optional alternative charge cost: `D_<5 = max(5−N_A,0)+max(5−N_B,0)`; do not assume independent or nonoverlapping with D_empty.

### 4c. Proposed trial optimization objective

`F[T] = <T| H_CAS + μ_empty D_empty + η_spin C_spin |T>/<T|T>`.

`μ_empty` has energy units; `η_spin` is dimensionless when multiplying C_spin in energy units. These are trial design hyperparameters, *not* the actual physical U and J. Baseline comparisons: original H-only, empty-only, spin-only, joint. Original H-only Ritz is by definition lowest **H-energy** in a fixed selected subspace; penalties can help by modifying the determinant **selection path**, not by lowering H variational energy on the same fixed subspace.

**Major open point:** no proof that D_empty=0 or minimum spin cost dominates the true molecular ground state. Preserve full Fe–S covalency and sector couplings. Do not extrapolate a Hubbard `U≫t` gap argument without checking physical energy blocks/couplings.

## 5. Sector weight optimization pilot (actually computed)

Separate trial basis *direction* optimization from *sector weight* optimization. Singlet-projected UHF pilot used `v_α=P_α T0` and generalized eigenproblem `Kc=ESc` with off-diagonal Hamiltonian sector couplings included; a small remainder direction ensured the original trial was contained.

Energies (active space, Ha):
- singlet-UHF start `−116.51423658`;
- simple one-parameter penalty `−116.51426954` (~0.03296 mHa improvement);
- two-parameter `h,m` correlator `−116.52701740` (~12.78082 mHa improvement);
- 25-sector charge Ritz `−116.57094315` (~56.70657 mHa improvement);
- DMRG reference `−116.60560910` (25-sector trial still ~34.67 mHa high).

Definitions: `h=N_A+N_B−10` (ligand hole count) and `m=|N_A−N_B|`. Two-parameter `exp(−λ_h h−λ_m m)` optimizes to `λ_h≈−0.059084`, `λ_m≈+0.177918`, **negative ligand-hole penalty** means some ligand→Fe character should be enhanced, not suppressed. This is a small-space **variational** result, not proof of improved AFQMC bias or SOTA accuracy.

## 6. AFQMC evaluator insight — finite Fourier representation for charge filter

For any correlator `G=f(N_A,N_B)` depending only on these two local charges (each integer 0..10), exact discrete Fourier expansion:

`G = Σ_{k,l=0}^{10} \tilde f_{kl} exp(2πik N_A/11) exp(2πil N_B/11)`, with `\tilde f=FFT2(f)/121` under the implemented convention.

Thus **at most 121 one-body phase operators**, applicable as Slater-orbital row phases, exactly reproduce the charge-only filter. For a parent M-determinant trial, naive evaluation includes up to `121M` transformed determinant terms; benchmark real SAFIRE cost separately. This expansion does NOT implement generic D_empty or S² filter; those need further representations. At Fe₄S₄, naive four-metal charge grid would have 11⁴=14,641 terms.

`charge_filter.py` provides exact filter and validation. The overlap, force bias, energy numerator, phase/constraint and walker updates must all use a **consistent** correlated trial. No SAFIRE integration is claimed yet.

## 7. Previously developed error-analysis concept

Given approximate high-accuracy reference ψ_ref and orthogonal sector projectors P_α, define `u_α=P_α ψ_ref/||P_α ψ_ref||`, `Π=Σ_α |u_α><u_α|`, and separate trial and coherent ket components parallel and orthogonal to Π. Decompose a mixed-energy error built from `H−E_ref` into four pairings `∥∥`, `∥⊥`, `⊥∥`, `⊥⊥`, grouped as B_sector and B_other. Explicitly monitor reference residual `(H−E_ref)|ψ_ref>`. This is a diagnostic requiring a *reference wavefunction*, which is not included merely by possessing a scalar DMRG energy. Don't equate coherent proxy errors to phaseless AFQMC production bias without validation.

## 8. What is and is not done

**Done/checked:** source FCIDUMP, group definitions/checksum; local ERI statistics; multiple local-spin spectra and embedding sensitivity; numerical checks of fixed selected-space objective; independent charge-sector Ritz diagonalization; exact 121-term charge correlator implementation/self-test; script/package manifest.

**Not yet done:** complete correlation-guided TrimCI grow-optimize-trim loop; hyperparameter selection; low-sector ground-state fidelity/population reference; consistent total-spin enforcement in every growth step; 2Fe2S SAFIRE with new trial; any demonstrated phaseless AFQMC improvement; resource-validated 4Fe4S scaling.

## 9. Next concrete experiments requested by user

1. Inspect existing TrimCI implementation and establish source-system comparability with the package FCIDUMP, orbital basis and selected determinant selection conventions. Keep active-space Hamiltonian unchanged.
2. Reproduce the included self-tests and provide numerical output, preserving existing files.
3. Implement a minimal **4-arm fixed-budget** experiment: (a) H-only TrimCI; (b) correlation-guided penalty TrimCI; (c) H-only + charge-sector reweighting; (d) correlation-guided + charge-sector reweighting. Try small determinant budgets first and control initial state, expansion, iteration count, spin adaptation, and final H-only variational energy evaluation.
4. Compare energy, residual, local charge/spin distributions, sector Ritz matrices and runtime, with same DMRG reference. Decide whether penalty changes selection beneficially, not only coefficients.
5. If feasible, construct a practical AFQMC-correlated trial evaluator; validate small overlap/force-bias/local-energy examples against exact 121-term charge filter before larger dynamics. Separate new Fe–S trial performance from ongoing Hubbard MH/PC issues.
6. Only after 2Fe₂S correctness and AFQMC pilot, consider Fe₄S₄ CAS(54e,36o) charge/spin operator scaling.

## 10. File navigation

Within `Fe2S2_trial_design/`:
- `README.md` — full Korean scientific report, with important qualifications.
- `MANIFEST.json` — checksums for included data and code.
- `fe2s2_model_v2/FCIDUMP` — active-space integrals.
- `fe2s2_model_v2/MODEL_SPEC.json` — model metadata.
- `fe2s2_model_v2/interaction_diagnostics.py`, `.json`, `INTERACTION_DIAGNOSTICS.md` — ERIs and local spin diagnostics.
- `fe2s2_model_v2/trial_operators.py`, `trial_operators_validation.json` — selected-space objective and tests.
- `fe2s2_model_v2/charge_filter.py`, `.json` — 121-term charge correlator and tests.
- `fe2s2_model_v2/validate_ritz.py`, `.json`, `validate_ritz_audit_ko.md` — sector Ritz rerun/verification.
- `sector_ritz.npz`, `sector_ritz.json`, `sector_ritz.py` and prior `closed_ligand`, `one_hole_bound` — stored pilot matrices/analyses.

External research starting point: `https://github.com/zhendongli2008/Active-space-model-for-Iron-Sulfur-Clusters`.

## 11. Reproduction commands

From unpacked `Fe2S2_trial_design/`:

```bash
python -m pip install numpy scipy
OPENBLAS_NUM_THREADS=1 python fe2s2_model_v2/interaction_diagnostics.py fe2s2_model_v2/FCIDUMP
OPENBLAS_NUM_THREADS=1 python fe2s2_model_v2/validate_ritz.py
OPENBLAS_NUM_THREADS=1 python fe2s2_model_v2/trial_operators.py --self-test --example --fcidump fe2s2_model_v2/FCIDUMP --spin-diagnostics fe2s2_model_v2/interaction_diagnostics.json --output fe2s2_model_v2/trial_operators_validation.json
python fe2s2_model_v2/charge_filter.py
```

Recommended starting prompt after extracting archive:

> Read `CODEX_HANDOFF_Fe2S2_2026-11-23.md` and `Fe2S2_trial_design/README.md`, inspect `MANIFEST.json`, verify source/integral conventions, then reproduce the self-tests. Compare the package to our existing TrimCI repository without overwriting files. Implement the smallest four-arm expand→optimize→trim benchmark on the supplied CAS(30e,20o) Hamiltonian, report exact numbers and runtime, and do not claim AFQMC improvements before running AFQMC. Preserve all source conventions and explain any mismatch.

**A note on transfer:** This Markdown file summarizes the discussion. To give Codex the literal entire ChatGPT exchange, use ChatGPT's *Share* / *Export data* UI separately; do not assume Codex CLI can automatically see this private conversation by default.
