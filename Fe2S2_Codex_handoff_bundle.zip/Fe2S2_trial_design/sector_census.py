"""Count spin and charge sectors of the oxidized Fe2S2 singlet benchmark.

Run: python sector_census.py [output.json]
Standard library only. This program reads no molecular integrals.
"""

import argparse
import json
from collections import Counter
from itertools import product
from math import comb, prod
from pathlib import Path

GROUP_SIZES = (5, 5, 10)
N_ELECTRONS = 30

# Reported weights in hundredths of one percent. Each unordered pair
# already includes the symmetry partner if the two site charges differ.
PUBLISHED = {
    (5, 5): 340,
    (5, 6): 2269,
    (6, 6): 4113,
    (5, 7): 605,
    (6, 7): 2201,
    (7, 7): 286,
}


def fragment_counts(orbitals, electrons):
    """Map the number of alpha electrons to the determinant count."""
    return {
        up: comb(orbitals, up) * comb(orbitals, electrons - up)
        for up in range(max(0, electrons - orbitals), min(orbitals, electrons) + 1)
    }


def count_sector(a, b, ligand):
    fragments = [
        fragment_counts(orbitals, electrons)
        for orbitals, electrons in zip(GROUP_SIZES, (a, b, ligand))
    ]
    by_up = Counter()
    for pattern in product(*(fragment.items() for fragment in fragments)):
        by_up[sum(up for up, _ in pattern)] += prod(n for _, n in pattern)
    ms0 = by_up[N_ELECTRONS // 2]
    ms1 = by_up[N_ELECTRONS // 2 + 1]
    h = 20 - ligand
    r = (abs(a - 5) + abs(b - 5) + h) // 2
    return dict(n_a=a, n_b=b, n_l=ligand, ligand_holes=h, transfer_count=r,
                determinants_ms0=ms0, singlets=ms0 - ms1)


def unordered_pair(row):
    return tuple(sorted((row["n_a"], row["n_b"])))


def cumulative(rows, label):
    represented_pairs = {unordered_pair(row) for row in rows}
    unreported_pairs = represented_pairs - PUBLISHED.keys()
    residual = 10000 - sum(PUBLISHED.values())
    result = []
    for k in range(1 + max(row[label] for row in rows)):
        within = [row for row in rows if row[label] <= k]
        within_pairs = {unordered_pair(row) for row in within}
        known = sum(w for pair, w in PUBLISHED.items() if pair in within_pairs)
        # All six percentages are rounded as reported. Assign the unlisted
        # remainder freely, except where the cutoff fixes its membership.
        lower = known + (residual if unreported_pairs <= within_pairs else 0)
        upper = known + (residual if unreported_pairs & within_pairs else 0)
        result.append(dict(
            cutoff=k,
            singlets=sum(row["singlets"] for row in within),
            determinants_ms0=sum(row["determinants_ms0"] for row in within),
            published_pct_accounted_inside=known / 100,
            compatible_total_weight_pct=[lower / 100, upper / 100],
        ))
    return result


def build():
    capacity_l = 2 * GROUP_SIZES[2]
    rows = [
        count_sector(a, b, N_ELECTRONS - a - b)
        for a in range(2 * GROUP_SIZES[0] + 1)
        for b in range(2 * GROUP_SIZES[1] + 1)
        if 0 <= N_ELECTRONS - a - b <= capacity_l
    ]
    ms0 = sum(row["determinants_ms0"] for row in rows)
    singlets = sum(row["singlets"] for row in rows)
    n_orb = sum(GROUP_SIZES)
    half = N_ELECTRONS // 2
    correct_ms0 = comb(n_orb, half) ** 2
    correct_s = correct_ms0 - comb(n_orb, half + 1) * comb(n_orb, half - 1)
    ionic, = [row for row in rows if row["n_a"] == row["n_b"] == 5]
    assert (ms0, singlets) == (correct_ms0, correct_s) == (240374016, 52581816)
    assert ionic["singlets"] == 75 ** 2 + 24 ** 2 + 1 == 6202
    assert sum(PUBLISHED.values()) == 9814 and len(rows) == 66
    paired = {(row["n_a"], row["n_b"]): row for row in rows}
    assert all(row["singlets"] == paired[b, a]["singlets"] for (a, b), row in paired.items())
    assert all(row["singlets"] > 0 for row in rows)
    dimensions = dict(ordered_charge_sectors=len(rows), singlets=singlets, determinants_ms0=ms0)
    cited_rows = [
        dict(unordered_fe_d_occupations=[a, b], n_l=N_ELECTRONS - a - b,
             published_pct=pct / 100)
        for (a, b), pct in sorted(PUBLISHED.items())
    ]
    return dict(
        system="Oxidized [Fe2S2(SCH3)4]2-, 30 active electrons in 20 spatial orbitals",
        definitions={
            "fragments": "Orthogonal subspaces of dimension 5,5,10 for Fe A 3d, Fe B 3d, and all remaining ligand orbitals.",
            "basis": "Dimensions are prior to any spatial symmetry restriction. A and B are labeled in the dimension counts.",
            "spin": "Spin-free Hamiltonian. Singlet count is the number of M_S=0 determinants minus the number of M_S=1 determinants in the same charge block.",
            "ligand_holes": "h=20-n_l",
            "transfer_count": "r=(abs(n_a-5)+abs(n_b-5)+h)/2, the minimum number of interfragment electron transfers from (5,5,20).",
        },
        dimensions=dimensions,
        sectors=rows,
        reported_ici={
            "source": "N. Zhang, W. Liu, M. R. Hoffmann, Further Development of iCIPT2 for Strongly Correlated Electrons, section 7.3; https://arxiv.org/pdf/2011.09096",
            "scope": "Selected singlet CSF expansion at Cmin=5e-6. We interpret formal Fe(III), Fe(II), Fe(I) labels as d5, d6, d7 in the authors' orbital grouping. These weights need not be preserved by alternative metal-ligand orbital assignments.",
            "rows": cited_rows,
            "reported_weight_pct": sum(PUBLISHED.values()) / 100,
            "unlisted_weight_pct": (10000 - sum(PUBLISHED.values())) / 100,
            "leading_csf_weight_pct": 3.36,
            "leading_csf_sector": [5, 5, 20],
            "conditional_squared_overlap_leading_csf_with_selected_ionic_sector_pct": 100 * 336 / PUBLISHED[5, 5],
            "conditional_overlap_note": "3.36/3.40 from rounded reported weights, for this particular normalized CSF and the selected wavefunction projected into its reported Fe(III)-Fe(III) sector.",
        },
        cutoffs={
            "note": "Weight intervals account for 1.86% unlisted, ignoring rounding of input percentages. No renormalization. A cutoff includes sectors with label <= k.",
            "ligand_holes": cumulative(rows, "ligand_holes"),
            "transfer_count": cumulative(rows, "transfer_count"),
        },
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", nargs="?", default="sector_census.json", type=Path)
    args = parser.parse_args()
    args.output.write_text(json.dumps(build(), indent=2) + "\n", encoding="utf-8")
