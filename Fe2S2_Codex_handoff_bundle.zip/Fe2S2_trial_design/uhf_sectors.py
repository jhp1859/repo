"""Charge probabilities and conditional energies of a spin-projected Fe2S2 UHF trial.

Run with python uhf_sectors.py FCIDUMP --output uhf_sectors.json.
Dependencies: numpy, pyscf. Orbital order is specific to the authors' Li–Chan file.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from numpy.polynomial.legendre import leggauss
from pyscf import ao2mo, gto, lib, scf
from pyscf.tools import fcidump
from scipy.linalg import block_diag

FINGERPRINT = '95d8786af06eeea2107e19ffd98c66a6ca97fc8c9864175a4f6d64512b6f2df9'
FE_A = np.arange(2, 7)
FE_B = np.arange(13, 18)


def uhf_trial(h1, eri):
    norb = len(h1)
    ligands = np.setdiff1d(np.arange(norb), np.r_[FE_A, FE_B])
    molecule = gto.M(verbose=0)
    molecule.nelectron = 30
    molecule.incore_anyway = True
    mean_field = scf.UHF(molecule)
    mean_field.get_hcore = lambda *args: h1
    mean_field.get_ovlp = lambda *args: np.eye(norb)
    mean_field._eri = eri
    mean_field.max_cycle = 400
    mean_field.conv_tol = 1e-11
    mean_field.conv_tol_grad = 1e-8
    initial_density = np.zeros((2, norb, norb))
    initial_density[:, ligands, ligands] = 1
    initial_density[0, FE_A, FE_A] = 1
    initial_density[1, FE_B, FE_B] = 1
    mean_field.kernel(dm0=initial_density)
    if not mean_field.converged:
        raise RuntimeError('The broken-symmetry UHF iteration did not converge.')
    occupied = [c[:, occ > 0] for c, occ in zip(mean_field.mo_coeff, mean_field.mo_occ)]
    return *occupied, mean_field.e_tot, mean_field.spin_square()[0]


def fragment_conserving_integrals(h1, eri):
    # 1, 3, 9 uniquely encode an unordered pair of up to two fragment labels.
    fragments = np.full(len(h1), 9)
    fragments[FE_A] = 1
    fragments[FE_B] = 3
    pair = fragments[:, None] + fragments[None, :]
    # Chemist's (pq|rs) creates in p,r and annihilates in q,s.
    return (h1 * (fragments[:, None] == fragments[None, :]),
            eri * (pair[:, None, :, None] == pair[None, :, None, :]))


def transition(bra, ket):
    metric = bra @ ket
    overlap = np.linalg.det(metric)
    density = ket @ np.linalg.solve(metric, bra)
    return overlap, density


def local_energy(density, h1, eri):
    norb = len(h1)
    blocks = density.reshape(2, norb, 2, norb)
    charge = blocks[0, :, 0, :] + blocks[1, :, 1, :]
    value = np.einsum('pq,qp', h1, charge)
    value += 0.5 * np.einsum('pqrs,qp,sr', eri, charge, charge, optimize=True)
    for spin in range(2):
        for other in range(2):
            value -= 0.5 * np.einsum('pqrs,sp,qr', eri, blocks[other, :, spin, :],
                                     blocks[spin, :, other, :], optimize=True)
    return value


def projected_moments(ca, cb, h1, eri):
    n = len(h1)
    occupied = block_diag(ca, cb)
    h1_block, eri_block = fragment_conserving_integrals(h1, eri)
    rotation = []
    # M_S=0. Max S=5 for 10 holes, so six nodes more than suffice for S projection.
    z, w = leggauss(6)
    for x, weight in zip(z, w):
        c, s = np.sqrt((1 + x) / 2), np.sqrt((1 - x) / 2)
        rot = np.block([[c * ca, -s * cb], [s * ca, c * cb]])
        rotation.append((weight / 2, rot))

    # 0..10 possible electrons per Fe shell: an 11-point DFT resolves all counts.
    roots = np.exp(2j * np.pi * np.arange(11) / 11)
    f = np.zeros((3, 11, 11), dtype=complex)
    singlet_energy_numerator = 0.0j
    for a, za in enumerate(roots):
        for b, zb in enumerate(roots):
            phase = np.ones(n, complex)
            phase[FE_A], phase[FE_B] = za, zb
            bra = occupied.T.conj() * np.tile(phase, 2)
            f[0, a, b] = np.linalg.det(bra @ occupied)
            for weight, rot in rotation:
                overlap, density = transition(bra, rot)
                f[1, a, b] += weight * overlap
                f[2, a, b] += weight * overlap * local_energy(density, h1_block, eri_block)
                if a == b == 0:
                    singlet_energy_numerator += weight * overlap * local_energy(density, h1, eri)
    moments = np.fft.fft2(f, axes=(-2, -1)) / 121
    if np.max(abs(moments.imag)) > 1e-10:
        raise ArithmeticError('Complex residue in the projected charge moments.')
    probabilities, singlet_norm, block_energy = moments.real
    norm = singlet_norm.sum()
    if (abs(probabilities.sum() - 1) > 1e-10 or abs(norm-f[1,0,0].real) > 1e-10
        or np.min(probabilities) < -1e-10 or np.min(singlet_norm) < -1e-10):
        raise ArithmeticError('Failed probability normalization or positivity check.')
    _, ref_density = transition(occupied.T.conj(), occupied)
    return (probabilities, singlet_norm / norm, block_energy / norm, norm,
            singlet_energy_numerator.real / norm, local_energy(ref_density, h1, eri))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('fcidump', type=Path)
    parser.add_argument('--output', type=Path, default=Path('uhf_sectors.json'))
    args = parser.parse_args()
    digest = hashlib.sha256(args.fcidump.read_bytes()).hexdigest()
    if digest != FINGERPRINT:
        raise ValueError('This pilot is for the published Li–Chan localized integral file.')
    lib.num_threads(1)
    x = fcidump.read(str(args.fcidump), verbose=False)
    if (x['NORB'], x['NELEC'], x['MS2'], x['ECORE']) != (20, 30, 0, 0):
        raise ValueError('Invalid active-space metadata.')
    h1 = x['H1']
    ca, cb, e_uhf, spin_square = uhf_trial(h1, x['H2'])
    eri = ao2mo.restore(1, x['H2'], x['NORB'])
    p, p0, block, norm, e_s0, e_check = projected_moments(ca, cb, h1, eri)
    if abs(e_check - e_uhf) > 2e-9:
        raise ArithmeticError('Full-Hamiltonian density contraction failed the UHF energy test.')
    rows = []
    threshold = 1e-8
    for a in range(11):
        for b in range(11):
            ell = 30 - a - b
            if ell <= 20:
                rows.append({'n_FeA': a, 'n_FeB': b, 'n_ligand': ell,
                             'p_UHF': max(p[a,b], 0), 'p_singlet': max(p0[a,b], 0),
                             'conditional_singlet_trial_energy_Eh':
                                 block[a,b] / p0[a,b] if p0[a,b] >= threshold else None})
    payload = {'sha256': digest, 'energy_offset_Eh': 0.0, 'UHF_energy_Eh': e_uhf,
               'UHF_S2': spin_square, 'UHF_singlet_probability': norm,
               'S0_projected_UHF_energy_Eh': e_s0,
               'S0_projected_UHF_block_diagonal_energy_Eh': block.sum(),
               'conditional_energy_probability_threshold': threshold, 'sectors': rows}
    args.output.write_text(json.dumps(payload, indent=2) + '\n')


if __name__ == '__main__':
    main()
