"""Full-Hamiltonian Rayleigh–Ritz reweighting for the singlet-projected UHF trial.

Run in the same directory as uhf_sectors.py:
  OPENBLAS_NUM_THREADS=1 python sector_ritz.py FCIDUMP --output sector_ritz.json
Requires numpy, scipy, pyscf. The fragment labels and file are verified by SHA-256.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from numpy.polynomial.legendre import leggauss
from pyscf import ao2mo, lib
from pyscf.tools import fcidump
from scipy.linalg import block_diag
from scipy.optimize import minimize
from numpy.polynomial import Polynomial

from uhf_sectors import FE_A, FE_B, FINGERPRINT, local_energy, transition, uhf_trial


def charge_changes(n):
    # The row sector i and column sector j obey j_X = i_X - Delta_X.
    axes = []
    for subset in (FE_A, FE_B):
        indicator = np.zeros(n, dtype=int)
        indicator[subset] = 1
        axes.append(indicator[:, None] - indicator[None, :])
    delta_a, delta_b = axes
    def encode(a, b):
        return 5 * (a + 2) + (b + 2)
    one = encode(delta_a, delta_b)
    two = encode(delta_a[:, :, None, None] + delta_a[None, None, :, :],
                 delta_b[:, :, None, None] + delta_b[None, None, :, :])
    return np.ascontiguousarray(one.ravel()), np.ascontiguousarray(two.ravel())


def binned_terms(labels, contributions):
    flat = contributions.ravel()
    return (np.bincount(labels, weights=flat.real, minlength=25) +
            1j * np.bincount(labels, weights=flat.imag, minlength=25))


def h_transfer_components(density, h, g, one, two):
    n = len(h)
    blocks = density.reshape(2, n, 2, n)
    charge = blocks[0, :, 0, :] + blocks[1, :, 1, :]
    one_terms = h * charge.T
    pair = np.einsum('qp,sr->pqrs', charge, charge)
    for i in range(2):
        for j in range(2):
            pair -= np.einsum('sp,qr->pqrs', blocks[j, :, i, :], blocks[i, :, j, :])
    return binned_terms(one, one_terms) + 0.5 * binned_terms(two, pair * g)


def sector_matrix(ca, cb, h, eri):
    n = len(h)
    occupied = block_diag(ca, cb)
    x, w = leggauss(6)
    rotation = []
    for node, weight in zip(x, w):
        c, s = np.sqrt((1 + node) / 2), np.sqrt((1 - node) / 2)
        rotation.append((weight / 2, np.block([[c * ca, -s * cb], [s * ca, c * cb]])))
    one, two = charge_changes(n)
    ngrid = 11
    roots = np.exp(2j * np.pi * np.arange(ngrid) / ngrid)
    generating = np.zeros((26, ngrid, ngrid), complex)
    exp_full = 0j
    for ia, za in enumerate(roots):
        for ib, zb in enumerate(roots):
            phases = np.ones(n, complex)
            phases[FE_A], phases[FE_B] = za, zb
            bra = occupied.T.conj() * np.tile(phases, 2)
            for weight, rot in rotation:
                overlap, density = transition(bra, rot)
                factor = overlap * weight
                generating[0, ia, ib] += factor
                generating[1:, ia, ib] += factor * h_transfer_components(density, h, eri, one, two)
                if ia == ib == 0:
                    exp_full += factor * local_energy(density, h, eri)
    singlet_norm = generating[0, 0, 0].real
    moments = np.fft.fft2(generating, axes=(-2, -1)) / (ngrid**2 * singlet_norm)
    if np.max(np.abs(moments.imag)) > 1e-10:
        raise ArithmeticError('Fourier sector matrix has imaginary residue.')
    sector_list = [(a, b) for a in range(11) for b in range(11) if a + b >= 10]
    index = {ab: i for i, ab in enumerate(sector_list)}
    p = np.array([moments[0, a, b].real for a, b in sector_list])
    H = np.zeros((len(p), len(p)))
    for i, (a, b) in enumerate(sector_list):
        for da in range(-2,3):
            for db in range(-2,3):
                j = index.get((a-da,b-db))
                if j is not None:
                    H[i,j] = moments[1 + 5*(da+2) + (db+2),a,b].real
    energy = exp_full.real / singlet_norm
    checks = {'probability_error': float(abs(p.sum()-1)),
              'max_imaginary_Eh_or_weight': float(abs(moments.imag).max()),
              'antihermitian_max_Eh': float(abs(H - H.T).max()),
              'total_energy_error_Eh': float(abs(H.sum()-energy))}
    if max(checks.values()) > 1e-10 or min(p) < -1e-12:
        raise ArithmeticError(f'Failed norm, reality, Hermiticity or energy closure: {checks}')
    return sector_list, p, (H + H.T) / 2, energy, checks


def ritz(sectors, p, H, reference, labels):
    unique = list(dict.fromkeys(labels))
    mask = np.array([[int(label == group) for group in unique] for label in labels])
    norm = p @ mask
    if norm.min() < 1e-9:
        raise ArithmeticError('A merged Ritz direction has an unstable norm.')
    basis = mask / np.sqrt(norm)
    reduced_h = basis.T @ H @ basis
    e, coefficients = np.linalg.eigh(reduced_h)
    scale = basis @ coefficients[:,0]
    if p @ scale < 0:
        scale *= -1
    weights = p * scale**2
    if abs(weights.sum()-1)>1e-10 or e[0]>reference+1e-10:
        raise ArithmeticError('Ritz normalization or variational bound failed.')
    keys = [(5,5),(5,6),(6,5),(4,6),(6,4),(6,6)]
    return {'directions': len(unique), 'energy_Eh': float(e[0]),
            'gain_from_projected_UHF_mEh': float((reference-e[0])*1000),
            'squared_overlap_with_projected_UHF': float((p @ scale)**2),
            'selected_probabilities': {str(key): float(weights[sectors.index(key)]) for key in keys},
            'sector_probabilities': [float(max(0,x)) for x in weights],
            'sector_amplitude_multipliers': scale.tolist()}


def d_ct(ab):
    a,b = ab
    return (abs(a-5) + abs(b-5) + a + b - 10) // 2


def exponential_test(sectors, p, H, reference):
    distance = np.array([d_ct(s) for s in sectors])
    shifted = H - reference * np.diag(p)
    def branch(powers, sign):
        # q=exp(-|lambda|) lives in [0,1]. Enumerate every real stationary point
        # of the rational Rayleigh quotient plus both endpoints; use the shifted H.
        num = Polynomial(np.bincount((powers[:,None] + powers[None,:]).ravel(),
                                     weights=shifted.ravel()))
        den = Polynomial(np.bincount(2*powers, weights=p))
        derivative = num.deriv()*den-num*den.deriv()
        candidates = [0.,1.] + [float(q.real) for q in derivative.roots()
                                 if abs(q.imag)<1e-8 and 0<q.real<1]
        shift, q = min((num(q)/den(q),q) for q in candidates)
        weights = p * q**(2*powers) / den(q)
        return {'lambda': float(-sign*np.log(q)) if q else ('+inf' if sign>0 else '-inf'),
                'energy_Eh': float(reference+shift), 'gain_mEh': float(-shift*1000),
                'p_ionic': float(weights[sectors.index((5,5))])}
    positive = branch(distance,1)
    negative = branch(distance.max()-distance,-1)
    holes = np.array([sum(ab)-10 for ab in sectors])
    imbalance = np.array([abs(a-b) for a,b in sectors])
    feature = np.stack([holes, imbalance],axis=1)
    def objective(parameter):
        exponent = -feature @ parameter
        c = np.exp(exponent-max(exponent))
        metric = p @ c**2
        hc = shifted @ c
        e = c @ hc / metric
        g = -2 * ((c*(hc-e*p*c)) @ feature) / metric
        return e,g
    # Broad bounds avoid amplification of roundoff in exceedingly rare directions.
    opt = minimize(objective, [0.,0.], method='L-BFGS-B', jac=True,
                   bounds=[(-0.4,2.),(-0.4,2.)],
                   options={'gtol':1e-12, 'ftol':1e-15, 'maxiter':500})
    if not opt.success or np.linalg.norm(opt.jac)>1e-7:
        raise ArithmeticError('Two-parameter trial fit failed to converge: '+str(opt))
    return {'suppressing':positive,'signed':min([positive,negative],key=lambda v:v['energy_Eh']),
            'two_parameter':{'formula':'exp(-lambda_h*h-lambda_i*abs(N_FeA-N_FeB))',
                             'lambda_h':float(opt.x[0]),'lambda_i':float(opt.x[1]),
                             'bounds_per_parameter':[-0.4,2.0],
                             'gradient_norm_Eh':float(np.linalg.norm(opt.jac)),
                             'gain_mEh':float(-1000*opt.fun),
                             'energy_Eh':float(reference+opt.fun)}}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('fcidump',type=Path)
    parser.add_argument('--output',type=Path,default=Path('sector_ritz.json'))
    args = parser.parse_args()
    digest = hashlib.sha256(args.fcidump.read_bytes()).hexdigest()
    if digest != FINGERPRINT:
        raise ValueError('Expected the Li–Chan Fe2S2 FCIDUMP in its original orbital order.')
    lib.num_threads(1)
    inp=fcidump.read(str(args.fcidump), verbose=False)
    h=inp['H1'];g=ao2mo.restore(1, inp['H2'], inp['NORB'])
    ca, cb, _, _ = uhf_trial(h,inp['H2'])
    sectors, p, H, energy, checks = sector_matrix(ca, cb, h, g)
    threshold = 1e-6
    def stable_groups(initial):
        norms = {key: sum(prob for label,prob in zip(initial,p) if label==key) for key in set(initial)}
        return [v if norms[v]>=threshold else 'combined_remainder' for v in initial]
    modes = {'charge_transfer_count': [d_ct(ab) for ab in sectors],
             'ligand_holes': [sum(ab)-10 for ab in sectors],
             'Fe_charge_pairs_symmetric': [tuple(sorted(ab)) for ab in sectors],
             'Fe_charge_pairs_resolved': sectors}
    results={key: ritz(sectors, p, H, energy, stable_groups(labels)) for key,labels in modes.items()}
    out={'sha256':digest, 'sector_indices_N_FeA_N_FeB': sectors,
         'minimum_explicit_group_probability': threshold,
         'method': 'Entire parent singlet-projected UHF retained. Low-probability groups are summed as one residual direction. Within each charge sector its direction stays fixed.',
         'checks':checks, 'projected_UHF_energy_Eh':energy,
         'initial_probabilities':p.tolist(),'results':results,
         'single_exponential_Gutzwiller':exponential_test(sectors,p,H,energy)}
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    np.savez_compressed(args.output.with_suffix('.npz'), charges=np.array(sectors),
                        p=p, H=H, reference=energy)

if __name__=='__main__':
    main()
