# Fe₂S₂ CAS(30e,20o)의 sector 기반 trial 설계

## 현재 결론과 완료 범위

공개된 실제 분자 적분에서 전하·스핀 연산자를 정의하고, 국소 상호작용을 계산하고, 기존 sector 재가중 계산을 독립 선형대수로 재검산했다. 이 결과로 TrimCI에 삽입할 목적함수의 reference 구현과, 전하 재가중 trial을 AFQMC 평가기에 전달할 수 있는 정확한 유한 Fourier 표현을 만들었다.

완료한 작업은 적분 기반 물리 진단, 연산자 정의와 구현, 작은 고정 determinant 공간에서의 목적함수 검산, singlet-UHF trial의 sector 재가중 검증이다. 전체 grow–optimize–trim 반복을 사용한 새로운 TrimCI 계산과 SAFIRE 전파는 수행하지 않았다. 아래 수치가 AFQMC 개선이나 state-of-the-art 정확도를 입증하는 것은 아니다.

이번 결과는 새 계산과 기존 결과의 재분석을 함께 포함한다. `interaction_diagnostics.json`, `ionic_couplings_recheck.json`, `trial_operators_validation.json`, `charge_filter.json`은 이번 입력으로 새로 계산했다. `validate_ritz.json`은 기존 `sector_ritz.npz`의 K,p를 사용한 독립 재대각화와 새 correlator 최적화다. 닫힌 ligand 전하 블록 및 한 ligand-hole 고정 계산은 기존 `closed_ligand.json`, `one_hole_bound.json`의 결과를 사용했으며 이번에 큰 블록을 다시 대각화하지 않았다.

## 1. 입력 모델

대상은 산화형 [Fe₂S₂(SCH₃)₄]²⁻의 singlet, CAS(30e,20o)다. Li–Chan의 공개 FCIDUMP를 원래 궤도 순서로 사용한다. 20개 활성 궤도는 Fe 3d 10개, bridging S 3p 6개, terminal ligand와의 σ 결합 관련 4개로 구성된다.

1부터 세는 궤도 번호는 다음과 같다.

| 묶음 | 궤도 |
|---|---|
| Fe A | 3, 4, 5, 6, 7 |
| Fe B | 14, 15, 16, 17, 18 |
| ligand 그룹 L | 1, 2, 8, 9, 10, 11, 12, 13, 19, 20 |

`FCIDUMP`의 SHA-256은 `95d8786af06eeea2107e19ffd98c66a6ca97fc8c9864175a4f6d64512b6f2df9`다. 파일의 ECORE는 0이고 보고하는 에너지는 active-space 에너지다. 공식 저장소의 DMRG 기준은 −116.6056091 Ha이다. 유한 bond dimension의 고정밀 기준으로 사용한다.

전체 활성공간 Hamiltonian을 유지한다.

\[
H_{\rm CAS}=E_c+\sum_{pq\sigma}h_{pq}a^\dagger_{p\sigma}a_{q\sigma}
+\frac12\sum_{pqrs\sigma\tau}(pq|rs)
a^\dagger_{p\sigma}a^\dagger_{r\tau}a_{s\tau}a_{q\sigma}.
\]

이 H는 선택한 비상대론적 active-space 모델에 대해 완전하다. 활성공간 외 상관이나 상대론 효과까지 포함한 실제 분자 전체의 정확한 H를 뜻하지 않는다. 물리적 fragment 정의는 위 고정된 orthonormal 궤도 분할에 의존한다. CI 궤도를 Fe/ligand 사이에서 회전하면 fragment number 연산자도 함께 변환해야 한다.

## 2. 실제 적분에서 확인한 상호작용

화학자 표기에서 U_m=(mm|mm), V_mn=(mm|nn), J_mn=(mn|nm)로 정의했다.

| 평균 적분, eV | Fe A | Fe B |
|---|---:|---:|
| 같은 d 궤도 Coulomb U | 21.8887 | 21.8861 |
| 서로 다른 d 궤도 Coulomb V | 20.3088 | 20.3080 |
| 서로 다른 d 궤도 exchange J | 0.7525 | 0.7531 |

Fe 사이 직접 Coulomb 평균은 5.14993 eV다. 이 수치는 활성 궤도의 적분 크기이고 screened Hubbard U나 분자 전하이동 에너지가 아니다. 평균 U,V,J로 국소 Kanamori tensor를 만들면 원래 국소 ERI와 Frobenius 상대차가 약 6.4%다. 따라서 계산에서는 원래 tensor를 사용한다. 이 상대차는 에너지 오차율이 아니다.

각 Fe의 5궤도에서 모든 전자 수 N=0,…,10의 국소 스핀별 에너지를 계산했다. 리간드를 닫힌껍질로 고정하고 다른 Fe의 d⁵ 스핀 평균 밀도를 넣는 이온성 평균장 환경에서는 다음 비용을 얻었다.

| 같은 N에서 국소 스핀 변화 | Fe A, eV | Fe B, eV |
|---|---:|---:|
| d⁴, S=2 → 1 | 1.7276 | 1.7471 |
| d⁵, S=5/2 → 3/2 | 2.4234 | 2.4045 |
| d⁶, S=2 → 1 | 2.4426 | 2.4439 |
| d⁷, S=3/2 → 1/2 | 2.1050 | 2.1093 |

환경을 리간드 닫힌껍질만으로 바꾸면 d⁵의 첫 비용은 0.7616, 0.7187 eV가 된다. 그러므로 위 비용은 지정한 국소 환경의 진단값이며 분자 전체의 singlet–triplet gap으로 사용하면 안 된다. 두 embedding의 전체 표는 `interaction_diagnostics.json`에 있다.

## 3. 전하 이동을 모두 같은 doublon으로 다루면 생기는 문제

전하 sector를 α=(N_A,N_B,N_L), N_A+N_B+N_L=30으로 정의한다. 원래 H에 대해 ligand를 완전히 채운 singlet 블록의 기존 정확 대각화는 다음 결과를 준다.

| 전하 sector | (5,5,20) 대비 블록 최저 에너지 |
|---|---:|
| (5,5,20) | 0 |
| (6,4,20) | +16.6492 eV |
| (4,6,20) | +16.7277 eV |

반면 (6,5,19)에서 특정 ligand 궤도에 hole을 고정한 변분 상태의 에너지는 이미 기준보다 2.9651 eV 낮다. 이 수치는 해당 전체 블록 최저값의 상한이다. 전체 블록의 최저값은 이보다 같거나 낮다. 이 결과는 ligand→Fe 전하 이동을 일괄 고비용으로 처리하면 안 된다는 직접적인 근거다. 이들 블록 에너지는 분자 분광학적 여기 에너지와 정의가 다르다.

독립적으로 이온성 high-spin singlet u에 전체 H를 작용시켰다. R=(H−〈H〉)u의 제곱 노름 중 단일 ligand→Fe 이동이 약 97.626%, 단일 Fe→Fe 이동이 약 2.061%를 차지한다. 이는 출발 상태에서 H가 만드는 결합의 분율이다. 바닥상태의 sector 확률이나 AFQMC 에너지 오차 분율을 뜻하지 않는다.

문헌의 같은 적분에 대한 selected-CI 파동함수도 d⁶d⁶ 성분 41.13%, d⁵d⁵ 3.40%를 보고한다. 해당 분류는 궤도와 활성공간에 의존하므로 새 궤도에서 목표 확률로 강제하지 않는다.

## 4. 일반화한 doublon 및 상관 연산자

### 4.1 정확한 분류 좌표

\[
N_I=\sum_{p\in I,\sigma}n_{p\sigma},\qquad
\mathbf S_I=\frac12\sum_{p\in I,\sigma\tau}
a^\dagger_{p\sigma}\boldsymbol\sigma_{\sigma\tau}a_{p\tau}.
\]

N_A, N_B, S_A², S_B²는 함께 sector를 정의할 수 있다. 처음에는 66개의 가능한 ordered charge sector로 시작하고, 필요한 부분을 국소 스핀별로 나눈다. 총 spin S=0도 별도로 유지한다. M_S=0만 지정하면 singlet을 보장하지 않는다.

원래 H는 정확히 다음처럼 쓸 수 있다.

\[
H=\sum_\alpha P_\alpha H P_\alpha
+\sum_{\alpha\ne\beta}P_\alpha H P_\beta.
\]

첫 항은 sector 내부 물리, 둘째 항은 sector 사이 전하 이동과 혼합이다. 둘째 항을 보존한다. 이 대수적 분해 자체가 저차원 유효모델의 정확도를 보장하지는 않는다.

### 4.2 Hole doublon

전자 30개를 20개 공간 궤도에 넣으면 전자 doublon은 최소 10개다. 따라서 전역 D_e=0 공간은 비어 있다. 자연스러운 후보는

\[
D_{\rm empty}=\sum_{p=1}^{20}(1-n_{p\uparrow})(1-n_{p\downarrow})
=D_e-10\ge0.
\]

빈 전자 궤도, 즉 hole 두 개가 같은 궤도에 있는 경우를 센다. d⁵d⁵와 닫힌 ligand에서는 0이다. ligand→Fe 이동으로 d⁶d⁵ 또는 d⁶d⁶가 되어도 ligand hole이 서로 다른 궤도에 놓이면 여전히 0일 수 있다. d⁴d⁶에서는 Fe의 빈 궤도가 반드시 생겨 최소 1이다.

이 연산자는 유용한 후보지만 D_empty=0 전체가 고품질 저에너지 공간이라고 입증한 것은 아니다. 궤도 회전에 의존하며 spin-flip non-Hund 상태는 따로 구별해야 한다.

seniority Ω와는 Ω=30−2D_e=10−2D_empty 관계를 갖는다. 이 모델에서 낮은 hole doublon은 높은 electron seniority와 연결된다.

### 4.3 국소 Hund 비용

간단한 무차원 연산자는

\[
D_{\rm Hund}=\sum_{I=A,B}
\{S_{\max}(N_I)[S_{\max}(N_I)+1]-S_I^2\},
\quad S_{\max}(n)=\tfrac12\min(n,10-n).
\]

더 구체적으로 실제 계산된 국소 스핀별 에너지 차이를 사용한다.

\[
C_{\rm spin}=\sum_{I,N,S}
[\epsilon_{I,\min}(N,S)-\epsilon_{I,\min}(N)]P_{I,N,S}.
\]

이는 같은 전자 수에서 더 비싼 국소 스핀 상태에 실제 에너지 단위의 비용을 부여한다. 선택한 국소 환경에 의존한다. 전하 비용과 모든 orbital excitation을 완전히 대표하는 연산자는 아니다.

추가적인 전하 특징으로 D_<5=(5−N_A)_+ +(5−N_B)_+를 사용할 수 있다. 이 연산자와 D_empty는 다르다. 같은 charge sector 안에서도 orbital empty 수는 달라질 수 있다. 세 특징을 동시에 넣어야 한다고 정하지 않고 각각의 효과를 비교한다.

## 5. Correlation-guided TrimCI에 넣는 수학

최초 실험 목적함수 후보를

\[
\mathcal F[T]=\frac{\langle T|H_{\rm CAS}
+\mu_{\rm empty}D_{\rm empty}+\eta C_{\rm spin}|T\rangle}{\langle T|T\rangle}
\]

로 정한다. μ_empty는 에너지 단위, η는 무차원이다. 실제 Coulomb 적분 U,J와 구별되는 trial 설계 매개변수다. 첫 비교는 μ=η=0, charge-only, spin-only, 둘 다의 네 경우로 한다. 필요하면 D_<5를 대안으로 사용한다. 물리적 U를 다시 더하는 해석을 하지 않는다.

매 루프는 기존 TrimCI 구조를 따른다.

1. 현재 trial에 원래 H의 연결을 사용하여 후보 determinant를 확장한다.
2. 확장된 고정 공간에서 H와 penalty 행렬을 구성하고 목적함수의 Ritz 계수를 구한다.
3. 동일한 determinant 예산으로 trim한다. spin-adapted CSF 또는 spin-complete configuration을 사용하면 총 singlet 유지에 유리하다.
4. 잘라낸 공간에서 다시 Ritz 최적화한다.
5. 원래 H의 에너지, 잔차, 전하·스핀 분포, determinant 수를 기록한다.

원래 H만의 Ritz는 같은 고정 공간에서 원래 에너지를 이미 최소화한다. penalty의 가치는 determinant 선택 경로 또는 trial 구조의 개선에 있다. 같은 공간에서 H-only보다 더 낮은 H 에너지를 보장하지 않는다.

`trial_operators.py`는 fixed-space H와 penalty를 만드는 reference API다. Slater–Condon H builder는 검산용 O(M²) 구현이다. 전체 TrimCI 탐색기와 production solver는 별도로 연결해야 한다. 비투영된 M determinant의 계수만 바꾸므로 이 단계에서는 determinant 수가 늘지 않는다.

실제 N,S별 비용을 읽어 목적함수를 만드는 예는 다음과 같다.

```python
from fe2s2_model_v2.trial_operators import build_objective, physical_spin_penalty

_, ops = build_objective(H_selected, dets, {}, return_operators=True)
C_spin = physical_spin_penalty(
    dets, 'fe2s2_model_v2/interaction_diagnostics.json',
    embedding='ionic_meanfield_spectra',
)
H_objective = H_selected + mu_empty * ops['D_h'] + eta_spin * C_spin
```

이 함수는 완전한 Fe local Fock block에서 spin projector를 만든 후 선택된 공간으로 제한한다. 먼저 selected S²를 만든 뒤 비선형 함수를 적용하면, 선택된 공간이 spin-complete하지 않을 때 결과가 달라질 수 있으므로 그 순서를 사용하지 않는다.

## 6. Sector 비중 최적화의 실제 pilot

저공간 방향을 만드는 TrimCI 자체와 분리하여, singlet-projected UHF trial T₀의 전하 sector 방향을 고정한 pilot을 평가했다.

\[
v_\alpha=P_\alpha T_0,\quad
S_{\alpha\beta}=\delta_{\alpha\beta}\|v_\alpha\|^2,\quad
K_{\alpha\beta}=\langle v_\alpha|H_{\rm CAS}|v_\beta\rangle,
\quad Kc=ESc.
\]

매우 작은 sector는 한 remainder 방향에 합쳐 출발 trial을 정확히 포함했다. 원래 H의 sector 사이 결합도 모두 유지했다. DMRG 에너지는 최적화에 사용하지 않았다.

| Trial | active energy, Ha | 출발 대비 개선, mHa |
|---|---:|---:|
| singlet-UHF T₀ | −116.51423658 | 0 |
| 모든 최소 전하 이동 r에 단일 양의 penalty | −116.51426954 | 0.03296 |
| Fe d⁵ 미만 D_<5만 재가중 | −116.51549123 | 1.25465 |
| ligand hole h와 Fe imbalance m, 두 계수 | −116.52701740 | 12.78082 |
| 25개 전하 그룹의 전체 Ritz | −116.57094315 | 56.70657 |
| 고정밀 DMRG 기준 | −116.60560910 | — |

25방향 Ritz 후 DMRG 기준과의 차이는 약 34.67 mHa다. 이는 최종 목표 정확도에 도달한 trial이 아니다. sector 비중 조절에 실제 변분 효용이 있다는 첫 검증이다.

두 계수 correlator는 exp(−λ_h h−λ_m m), h=N_A+N_B−10, m=|N_A−N_B|이며 λ_h=−0.059084, λ_m=0.177918을 얻었다. ligand hole에 음의 계수가 나온 것은 해당 채널을 일부 증가시키는 것이 이 trial의 에너지에 유리함을 뜻한다. 모든 채널을 같은 방향으로 감쇠시키는 단일 Gutzwiller 형식에 한계가 있다.

## 7. AFQMC에서 전하 correlator의 정확한 표현

두 Fe charge만의 함수 G=f(N_A,N_B)라면 각각 0,…,10이므로 11점 유한 Fourier 합으로 정확하게 쓸 수 있다.

\[
G=\sum_{k,l=0}^{10}\widetilde f_{kl}
e^{2\pi i kN_A/11}e^{2\pi i lN_B/11},
\quad\widetilde f=\operatorname{FFT2}(f)/121.
\]

각 항은 일체 연산자다. 원래 Slater orbital matrix의 Fe A/B 행에 위상만 곱하면 된다. M determinant parent라면 최대 121M개의 변환된 항을 가지며, 원래 parent와 121개의 field 계수만 저장하고 필요시 그룹별로 생성·평가할 수 있다. spin projection이 별도 표현으로 들어 있으면 그 비용도 별도로 포함한다.

이 식은 charge-only filter에 관한 것이다. 모든 orbital별 hole doublon이나 local-spin projector가 같은 121항으로 평가되는 것은 아니다. Fe₄S₄에서 네 Fe charge를 독립적으로 쓰면 직접적인 곱 표현은 11⁴=14,641항이다. 실제 SAFIRE 비용을 별도로 측정해야 한다.

`charge_filter.py`는 현재 25방향 Ritz의 f table, Fourier 계수, Slater row 변환을 생성한다. 전체 121 charge eigenvalue에 대한 합산 및 무작위 Slater configuration 진폭 검산을 통과했다. 이 결과가 SAFIRE에서 overlap, force, constraint를 검증했다는 의미는 아니다.

AFQMC 연결에서는 같은 f로 overlap, force numerator, energy numerator를 함께 평가하고, bra를 만들 때 field와 계수의 복소켤레를 일관되게 사용해야 한다. 전파 Hamiltonian은 항상 원래 H_CAS다.

## 8. 기존 에러분석 프레임과의 연결

정규화한 고정밀 reference ψ_*와 완비 직교 sector P_α가 주어지면 u_α=P_αψ_*/||P_αψ_*||로 정의하고

\[
Q_\parallel=\sum_{\alpha:p_\alpha>0}|u_\alpha\rangle\langle u_\alpha|,
\qquad Q_\perp=1-Q_\parallel
\]

를 사용한다. 같은 coherent mixed estimator에 대해 H−E_*의 네 Q_parallel/Q_perp 결합으로 에너지 차이를 분해할 수 있다. approximate reference이면 Hψ_*−E_*ψ_* 잔차를 함께 보고한다.

현재 공개 energy 값만으로 reference sector fidelity와 이 분해를 계산할 수는 없다. 실제 DMRG MPS 또는 고정밀 selected-CI 파동함수가 필요하다. 이번 local/sector 계산에는 그 reference wavefunction을 사용하지 않았다. 또한 저장된 coherent ket의 분해와 production AFQMC estimator 평균은 별도로 정의해야 한다.

## 9. 검산과 재현

새 국소 H의 spin commutator 최대 원소는 약 7.1×10⁻¹⁵ Ha, local eigenpair 잔차는 7.5×10⁻¹⁴ Ha 이하다. 독립 생성·소멸 연산자와 Slater–Condon 결과는 5.3×10⁻¹⁵ Ha 이내다. charge Ritz의 독립 generalized diagonalization은 기존 에너지와 최대 1.7×10⁻¹³ Ha 차이다.

NumPy와 SciPy만으로 새 진단과 저장 행렬의 재검산을 실행할 수 있다. 원래 UHF/sector 행렬을 적분에서 다시 만들려면 PySCF도 필요하다. 아래 명령은 압축 해제된 패키지 루트에서 실행한다.

```sh
python -m pip install numpy scipy
OPENBLAS_NUM_THREADS=1 python fe2s2_model_v2/interaction_diagnostics.py fe2s2_model_v2/FCIDUMP
OPENBLAS_NUM_THREADS=1 python fe2s2_model_v2/validate_ritz.py
OPENBLAS_NUM_THREADS=1 python fe2s2_model_v2/trial_operators.py --self-test --example --fcidump fe2s2_model_v2/FCIDUMP --spin-diagnostics fe2s2_model_v2/interaction_diagnostics.json --output fe2s2_model_v2/trial_operators_validation.json
python fe2s2_model_v2/charge_filter.py
```

API 예제는 전하 이동을 제외한 252 determinant 공간을 사용하며 완전한 trial 성능 실험이 아니다. 파일별 CLI `--help`로 입력과 출력 위치를 확인할 수 있다. `MANIFEST.json`은 패키지에 포함한 파일의 SHA-256을 제공한다.

## 10. 다음 실제 성능 계산

첫 목표는 같은 입력, 초기 singlet, determinant 예산, TrimCI 반복 예산에서 H-only와 correlation-guided 목적함수를 비교하는 것이다. 그 뒤 각각에 같은 charge-sector 재가중을 적용한다. 구체적으로 H-only, penalty-guided, H-only+sector weights, penalty-guided+sector weights의 네 trial을 비교하면 방향 개선과 비중 개선을 분리할 수 있다.

AFQMC에서는 동일 time step, walker 수, projection time에서 추가 correlator 평가 오차와 trial 효과를 구분한다. 기존 Hubbard 문제에서 발생했던 stochastic overlap/constraint 문제를 분자의 trial 성능과 섞지 않는다. 2Fe의 charge-only 121항 정확 evaluator는 이 비교의 작은 기준으로 사용할 수 있다.

이 단계에서 결정되지 않은 것은 penalty의 최적 강도, ground state를 충분히 담는 low-sector cutoff, 최선의 orbital basis, 최종 AFQMC 정확도와 비용이다. 이들은 이번 연산자 정의를 이용해 직접 비교할 수 있는 실험 항목이다.

## 출처

- Li–Chan 공식 FCIDUMP와 DMRG 기준, https://github.com/zhendongli2008/Active-space-model-for-Iron-Sulfur-Clusters
- Li and Chan, Spin-Projected Matrix Product States, JCTC 13, 2681–2695 (2017), https://doi.org/10.1021/acs.jctc.7b00270
- Zhang, Liu, Hoffmann, Further Development of iCIPT2 for Strongly Correlated Electrons, §7.3, https://arxiv.org/html/2011.09096v1#S7.SS3
- Chilkuri, DeBeer, Neese, Ligand Field Theory and Angular Overlap Model Based Analysis of the Electronic Structure of Homovalent Iron–Sulfur Dimers, https://doi.org/10.1021/acs.inorgchem.9b00974
- Dobrautz et al., Spin-Pure Stochastic-CASSCF via GUGA-FCIQMC Applied to Iron–Sulfur Clusters, https://doi.org/10.1021/acs.jctc.1c00589

공개 적분의 출처와 checksum을 함께 보존한다. 원저자의 데이터에 대한 새 라이선스를 부여하지 않는다.
