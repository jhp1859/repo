# Fe₂S₂의 전하 sector와 trial 재가중

산화형 [Fe₂S₂(SCH₃)₄]²⁻, 전체 스핀 singlet의 CAS(30e,20o)를 대상으로 한다. 세 그룹의 전자 수 (N_A,N_B,N_L)로 직교하는 전하 sector를 정의한다. 공개 적분의 1부터 시작하는 번호로 Fe A는 3–7, Fe B는 14–18이고 리간드는 나머지 열 개 궤도다. 그룹을 섞는 궤도 회전은 이 정의를 바꾼다. 리간드 홀 수 h=20−N_L과 Fe 전자 수 차이 m=|N_A−N_B|를 함께 지정하면 Fe A와 B의 교환을 허용한 전하 sector가 정해진다.

## 입력과 재현

적분은 Z. Li와 G. K.-L. Chan의 공개 모델을 사용했다. 원 파일은 active-space 에너지만 담으며 ECORE=0이다. 결합과 에너지 차이는 Hartree 단위로 계산하고 1 Hartree=27.211386246 eV로 변환했다. 다음 명령은 압축을 푼 디렉터리에서 실행한다. 검증 환경은 Python 3.12, NumPy 2.3.5, SciPy 1.17.0, PySCF 2.15.1이다.

```sh
curl -L --fail -o FCIDUMP https://raw.githubusercontent.com/zhendongli2008/Active-space-model-for-Iron-Sulfur-Clusters/main/Fe2S2_and_Fe4S4/Fe2S2/fe2s2
sha256sum FCIDUMP
python -m pip install numpy scipy pyscf
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
python sector_census.py sector_census.json
python fe2s2_charge_model.py --self-test
python fe2s2_charge_model.py FCIDUMP --fe-a 3,4,5,6,7 --fe-b 14,15,16,17,18 --output couplings.json
python closed_ligand.py FCIDUMP --output closed_ligand.json
python one_hole_bound.py FCIDUMP --hole 8 11 --charge-a 6 --output one_hole_A.json
python one_hole_bound.py FCIDUMP --hole 10 --charge-a 5 --output one_hole_B.json
python uhf_sectors.py FCIDUMP --output uhf_sectors.json
python sector_ritz.py FCIDUMP --output sector_ritz.json
```

원본 SHA-256은 `95d8786af06eeea2107e19ffd98c66a6ca97fc8c9864175a4f6d64512b6f2df9`이다. 두 one_hole 결과를 합친 파일이 one_hole_bound.json이다.

## 계산과 해석

- **전하 블록의 에너지**는 각 블록의 singlet 부분공간으로 제한한 원래 분자 해밀토니안의 최저 고유값이다. (5,5,20)의 에너지는 −115.95373089 Ha이다. (6,4,20)과 (4,6,20)은 각각 +16.6492 eV, +16.7277 eV 높다. 두 Fe→Fe 방향을 한 블록에 함께 넣어 방향 간 결합까지 허용한 최저값은 기준 대비 +16.6465 eV이다. 리간드가 닫힌 각 계산은 해당 블록의 모든 허용 배치를 포함했다. 리간드가 모두 이중점유되어 있으므로 열 개의 Fe d 궤도만 남기는 닫힌껍질 축약이 정확하다. 최저 고유쌍의 H 잔차와 S² 작용의 노름을 확인했고, 시작 난수와 스핀 페널티를 바꿔 세 에너지가 3×10⁻¹⁴ Ha 이내에서 일치함을 확인했다.
- **리간드 홀을 한 궤도에 두는 변분 계산**은 전체 전하 블록 최저 에너지의 상한을 준다. (6,5,19)에서 11번 궤도에 홀을 두면 기준 대비 −2.9651 eV, 반대 방향인 (5,6,19)에서 10번에 두면 −2.9034 eV이다. 홀을 이동시키거나 여러 홀 위치를 간섭시킬 수 있는 전체 블록의 최저값은 이 값 이하다. (6,6,18)에서는 전하·스핀 투영 UHF의 에너지가 이미 기준보다 3.0948 eV 낮다. 에너지는 모두 특정 fragment 점유를 강제한 값이며 분광 여기 에너지와는 정의가 다르다.
- **출발 상태와 각 블록 사이의 결합**은 두 Fe의 지역 스핀 5/2를 전체 singlet으로 결합하고 리간드를 채운 상태 u에서 계산했다. R=(H−〈u|H|u〉)u를 구성하고 각 블록의 제곱 노름을 더했다. 전체 ||R||=0.2900890 Ha, 단일 리간드→Fe 두 방향은 ||P R||=0.2866252 Ha, 단일 Fe→Fe 두 방향은 0.0416415 Ha이다. 전체 제곱 노름의 각 97.626%, 2.061%이다. 이 분율의 분모는 출발 상태의 에너지 분산이다.
- **전하와 스핀 투영 UHF**에서는 깨진 대칭 UHF를 먼저 수렴시킨 후 전체 singlet과 전하 블록으로 투영한다. UHF의 S² 기대값은 4.89315이고 singlet 투영 노름 제곱은 0.17028이다. 두 Fe의 전자 수를 추출하는 정확한 11×11 이산 푸리에 합과 스핀 투영을 사용한다. JSON은 투영한 trial의 전하 비중과 조건부 에너지를 담는다.
- **공간의 크기와 문헌 비교**에서 총 singlet은 52,581,816개, 이온성 전하 블록의 singlet은 6,202개이다. 각 Fe에 Hund 최대스핀을 추가로 고정하면 단 하나의 singlet이 남는다. sector_census.json은 이 조합론적 수치와 별도로 Zhang 등의 selected-CI 비중도 수록한다. 그 논문의 산화수 분류를 d 전자 수로 대응시켰고, 논문이 열거하지 않은 1.86%를 재정규화하지 않았다.

## Sector 진폭 Ritz

정규화한 singlet UHF T에 대해 qα=〈T|Pα|T〉, Kαβ=〈T|Pα H Pβ|T〉를 구한다. 각 그룹 g에 포함된 Pα T를 합친 다음 단위 노름으로 나눈 벡터를 Ritz 기저로 썼다. 그룹의 시작 비중이 10⁻⁶ 미만인 경우 해당 그룹들을 한 벡터로 합쳐 출발 trial을 항상 표현할 수 있게 했다. 에너지 최소화에는 DMRG 결과가 쓰이지 않는다.

| 독립적으로 계수를 정한 그룹 | 방향 수 | 변분 에너지 (Ha) | DMRG 기준과 차이 (mHa) |
|---|---:|---:|---:|
| 출발 singlet UHF | 1 | −116.51423658 | 91.373 |
| 이온성 배치에서 최소 전자 이동 횟수 r | 10 | −116.53708793 | 68.521 |
| 리간드 홀 수 h | 10 | −116.53766627 | 67.943 |
| 리간드 홀 수와 Fe 전자 수 차이 (h,m) | 25 | −116.57094315 | 34.666 |
| Fe A와 B를 구별한 전하쌍 | 40 | −116.57094315 | 34.666 |

같은 trial에 G=exp(−λr)을 적용해 에너지를 최소화하면 λ=0.006507, 이득은 0.03296 mHa이다. h와 m에 독립 계수를 주는 exp(−λ_h h−λ_m m)에서는 λ_h=−0.05908, λ_m=+0.17792에서 12.78082 mHa 내려갔다. 두 계수는 각 [−0.4,2.0] 범위의 내부에서 최적화했다. sector_ritz.npz에는 순서가 있는 66개 전하쌍, 원래 비중 p, 정규화 전의 K 행렬, 출발 에너지가 있어 이중계수 또는 다른 작은 trial을 다시 평가할 수 있다.

25방향 Ritz에서 (5,5,20)은 16.11%에서 5.44%, (6,6,18)은 17.54%에서 37.35%가 되었다. 단일 Fe→Fe 이동 두 방향의 합은 0.1412%에서 0.0173%가 되었다. 단일 리간드→Fe 이동 두 방향의 합은 33.42%에서 28.85%가 되었다. 이 결과는 각 sector 내부 방향을 고정하고 계수만 조절했을 때의 변분 효과다. 더 세분한 그룹에는 자유도가 더 많다. AFQMC mixed-energy 오차와 수평·수직 분해는 독립 검증 과제다.

## 문헌

- Li & Chan, *Spin-Projected Matrix Product States*, JCTC (2017). https://doi.org/10.1021/acs.jctc.7b00270
- 원본 입력과 비교용 DMRG active-space 에너지 −116.6056091 Ha. https://github.com/zhendongli2008/Active-space-model-for-Iron-Sulfur-Clusters
- Zhang, Liu & Hoffmann, *Further Development of iCIPT2 for Strongly Correlated Electrons*, §7.3. https://arxiv.org/abs/2011.09096
- Chilkuri, DeBeer & Neese, *Ligand Field Theory and Angular Overlap Model Based Analysis of the Electronic Structure of Homovalent Iron–Sulfur Dimers*. https://doi.org/10.1021/acs.inorgchem.9b00974
