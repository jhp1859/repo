"""Lowest singlet energies in exact ligand-closed charge blocks of the Li–Chan dimer.

Usage: OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python closed_ligand.py FCIDUMP
Requires numpy, scipy and pyscf. The Fe masks below use this file's original ordering.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from pyscf import ao2mo, fci
from pyscf.tools import fcidump
from scipy.sparse.linalg import LinearOperator, eigsh

# Python indices are zero based. The input FCIDUMP labels the orbitals starting at one.
FE_A = list(range(2, 7))
FE_B = list(range(13, 18))
SOURCE_SHA256 = '95d8786af06eeea2107e19ffd98c66a6ca97fc8c9864175a4f6d64512b6f2df9'


def freeze_ligands(path):
    data = fcidump.read(str(path), verbose=False)
    assert (data['NORB'], data['NELEC'], data['MS2']) == (20, 30, 0)
    fe = FE_A + FE_B
    lig = sorted(set(range(20)) - set(fe))
    eri = ao2mo.restore(1, data['H2'], 20)
    h = data['H1']
    ll = eri[np.ix_(lig, lig, lig, lig)]
    constant = (data.get('ECORE', 0.) + 2 * h[lig, lig].sum()
                + 2 * np.einsum('iijj->', ll) - np.einsum('ijji->', ll))
    effective_h = (h[np.ix_(fe, fe)]
                   + 2 * np.einsum('pqii->pq', eri[np.ix_(fe, fe, lig, lig)])
                   - np.einsum('piiq->pq', eri[np.ix_(fe, lig, lig, fe)]))
    return constant, effective_h, eri[np.ix_(fe, fe, fe, fe)]


def solve_blocks(path, seed, spin_penalty):
    offset, h1, g2 = freeze_ligands(path)
    f = fci.direct_spin1
    n, ne = 10, (5, 5)
    h2 = f.absorb_h1e(h1, g2, n, ne, .5)
    links = fci.cistring.gen_linkstr_index_trilidx(range(n), ne[0])
    strs = fci.cistring.make_strings(range(n), ne[0])
    up_count_a = np.array([(int(s) & 31).bit_count() for s in strs])
    n_a = up_count_a[:, None] + up_count_a[None, :]
    rng = np.random.default_rng(seed)
    result = []
    for charges in [[5], [6], [4], [4, 6]]:
        locations = np.flatnonzero(np.isin(n_a, charges))
        def apply_operators(vector):
            whole = np.zeros(n_a.shape)
            whole.flat[locations] = vector
            hv = f.contract_2e(h2, whole, n, ne, (links, links))
            ss = fci.spin_op.contract_ss(whole, n, ne)
            return hv.ravel()[locations], ss.ravel()[locations]

        def matvec(vector):
            hv, ss = apply_operators(vector)
            return hv + spin_penalty * ss

        m = len(locations)
        op = LinearOperator((m, m), matvec=matvec, dtype=float)
        _, vec = eigsh(op, k=1, which='SA', tol=1e-12, v0=rng.normal(size=m), maxiter=2200)
        vec = vec[:, 0]
        hv, ss = apply_operators(vec)
        en = vec @ hv
        residual = float(np.linalg.norm(hv - en * vec))
        s_norm = float(np.linalg.norm(ss))
        if s_norm > 1e-6 or residual > 2e-8:
            raise RuntimeError(f'Convergence or spin failure: N_A={charges}, residual={residual}, ||S²v||={s_norm}')
        row = dict(charges_in_block=[[a, 10-a, 20] for a in charges], ms0_dimension=m,
                   energy_Eh=float(en + offset), projected_H_residual_Eh=residual,
                   s_squared=float(vec @ ss), s_squared_vector_norm=s_norm)
        if len(charges) == 1:
            row['charge'] = row['charges_in_block'][0]
        print(json.dumps(row), flush=True)
        result.append(row)
    for row in result:
        row['difference_from_ionic_Eh'] = row['energy_Eh'] - result[0]['energy_Eh']
        row['difference_from_ionic_eV'] = row['difference_from_ionic_Eh'] * 27.211386246
    return dict(units='Hartree except where specified', input_sha256=SOURCE_SHA256,
                spin_penalty_Eh=spin_penalty, rng_seed=seed, ligand_closed_offset_Eh=float(offset),
                orbitals_one_based={'Fe_A':[p+1 for p in FE_A], 'Fe_B':[p+1 for p in FE_B]},
                scope='Minimum at S=0 within each fixed charge block, original active Hamiltonian, file ECORE included.',
                blocks=result[:3], combined_mmct_block=result[3])


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('fcidump', type=Path)
    p.add_argument('--output', type=Path, default=Path('closed_ligand.json'))
    p.add_argument('--seed', type=int, default=8419)
    p.add_argument('--spin-penalty', type=float, default=.25)
    args = p.parse_args()
    if hashlib.sha256(args.fcidump.read_bytes()).hexdigest() != SOURCE_SHA256:
        p.error('Expected the published Li–Chan file in its original orbital ordering (see README).')
    summary = solve_blocks(args.fcidump, args.seed, args.spin_penalty)
    args.output.write_text(json.dumps(summary, indent=2) + '\n')
