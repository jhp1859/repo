#!/usr/bin/env python3
"""Reference penalty operators in a selected orthonormal determinant space.

Spin-orbital bit order is p-alpha, p-beta, (p+1)-alpha, ... . Orbital indices
in this module are ZERO based. Defaults match the public Li-Chan Fe2S2 file.
No orbitals are rotated or determinants added by coefficient optimization.
The supplied physical Hamiltonian remains the one to use for physical energy
evaluation and AFQMC. This module is not a full TrimCI or AFQMC implementation.

Names: h = ligand holes; D_h = empty spatial orbitals in the WHOLE active
space. They are distinct. At N=30, L=20, D_h = D_e_total - 10 exactly.

Usage:
  python trial_operators.py --self-test --output trial_operators_validation.json
  python trial_operators.py --fcidump ../FCIDUMP --example

The example builds the ionic 252-determinant singlet support, a deliberately
small basis which excludes ligand charge transfer. It demonstrates the API,
not an adequate ground-state trial for this molecule.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from itertools import combinations
import json
from pathlib import Path
import sys
import numpy as np

FE_A = tuple(range(2, 7))
FE_B = tuple(range(13, 18))


def _determinants(dets, n_orb):
    dets = [int(d) for d in dets]
    if len(set(dets)) != len(dets):
        raise ValueError("Duplicate determinants are not an orthonormal basis")
    if any(d < 0 or d.bit_length() > 2*n_orb for d in dets):
        raise ValueError("Determinant has occupied bits outside the active space")
    return dets


def _groups(n_orb, fe_a, fe_b):
    a, b = tuple(fe_a), tuple(fe_b)
    if not a or not b or len(set(a+b)) != len(a)+len(b):
        raise ValueError("Fe orbital groups must be nonempty, disjoint and unique")
    if min(a+b) < 0 or max(a+b) >= n_orb:
        raise ValueError("Fe group index outside the active space")
    return a, b, tuple(sorted(set(range(n_orb))-set(a+b)))


def charge_values(dets, n_orb=20, fe_a=FE_A, fe_b=FE_B):
    """Return exact diagonal values, including doubles and hole counts.

    D_FeHole counts Fe electrons missing below one per local orbital. Thus
    d4d6 has value 1 and d6d6 has value 0. It is a proposed diagnostic/penalty,
    not an assertion that every state with positive value has high energy.
    """
    dets = _determinants(dets, n_orb)
    a, b, lig = _groups(n_orb, fe_a, fe_b)
    occupancy = np.array([[(d >> (2*p)) & 3 for p in range(n_orb)]
                          for d in dets], dtype=np.int8)
    if not dets:
        occupancy = np.empty((0, n_orb), dtype=np.int8)
    count = np.array([0, 1, 1, 2], dtype=np.int8)[occupancy]
    na, nb = count[:, a].sum(axis=1), count[:, b].sum(axis=1)
    nl = count[:, lig].sum(axis=1)
    doubles = (occupancy == 3).sum(axis=1)
    empty = (occupancy == 0).sum(axis=1)
    return dict(N=count.sum(axis=1), N_A=na, N_B=nb, N_L=nl,
                h=2*len(lig)-nl, m=np.abs(na-nb), m2=(na-nb)**2,
                D_FeHole=np.maximum(0, len(a)-na)+np.maximum(0, len(b)-nb),
                D_h=empty, D_e_total=doubles,
                D_e_fe=(occupancy[:, a+b] == 3).sum(axis=1),
                seniority=(count == 1).sum(axis=1))


def _apply(d, sequence):
    """Apply operators right to left, given in their execution order."""
    sign = 1
    for i, create in sequence:
        if bool((d >> i) & 1) == bool(create):
            return None, 0
        sign *= 1 - 2*((d & ((1 << i)-1)).bit_count() % 2)
        d ^= 1 << i
    return d, sign


def spin_squared(dets, orbitals, n_orb=20):
    """Matrix <di|S_group^2|dj>, without projecting ladder intermediates.

    Uses S^2=Sz^2+Sz+S- S+. Only the final determinant is restricted to
    the selected space. Multiplying two separately restricted S+/S- matrices
    would incorrectly give zero ladder contributions in an Ms-fixed basis.
    """
    dets = _determinants(dets, n_orb)
    orbitals = tuple(orbitals)
    if len(set(orbitals)) != len(orbitals) or any(p < 0 or p >= n_orb for p in orbitals):
        raise ValueError("Invalid spin-group orbital indices")
    lookup = {d:i for i,d in enumerate(dets)}
    matrix = np.zeros((len(dets), len(dets)))
    for j, d in enumerate(dets):
        sz = .5*sum(((d >> (2*p)) & 1)-((d >> (2*p+1)) & 1) for p in orbitals)
        matrix[j, j] += sz*sz+sz
        for q in orbitals:
            mid, plus = _apply(d, [(2*q+1, False), (2*q, True)])
            if not plus:
                continue
            for p in orbitals:
                final, minus = _apply(mid, [(2*p, False), (2*p+1, True)])
                if minus and final in lookup:
                    matrix[lookup[final], j] += plus*minus
    if not np.allclose(matrix, matrix.T, atol=1e-13, rtol=0):
        raise AssertionError("S squared matrix is not Hermitian")
    return matrix


def penalty_operators(dets, n_orb=20, fe_a=FE_A, fe_b=FE_B):
    """Build exact restricted matrices of candidate dimensionless operators."""
    dets = _determinants(dets, n_orb)
    a, b, _ = _groups(n_orb, fe_a, fe_b)
    values = charge_values(dets, n_orb, a, b)
    ops = {key:np.diag(values[key].astype(float))
           for key in ("D_h", "D_FeHole", "h", "m", "m2", "D_e_fe")}
    spin_a = spin_squared(dets, a, n_orb)
    spin_b = spin_squared(dets, b, n_orb)
    sa = .5*np.minimum(values["N_A"], 2*len(a)-values["N_A"])
    sb = .5*np.minimum(values["N_B"], 2*len(b)-values["N_B"])
    ops["D_Hund"] = np.diag(sa*(sa+1)+sb*(sb+1))-spin_a-spin_b
    return ops


def physical_spin_penalty(dets, diagnostics, embedding="ionic_meanfield_spectra",
                          n_orb=20, fe_a=FE_A, fe_b=FE_B,
                          return_components=False):
    """Compress sum_I sum_(N,S) DeltaE_I(N,S) P_I(N,S) to selected space.

    DeltaE_I(N,S)=min_energy_I(N,S)-min_energy_I(N) is taken in Hartree
    from interaction_diagnostics.json. It is an embedding-dependent cost
    used for trial guidance, not an extra term in the physical Hamiltonian.
    All orbital multiplets sharing (N,S) receive the same lowest-spin-sector
    cost, so this is not a full local-Hamiltonian spectral decomposition.

    Crucially, spin projectors are built in each COMPLETE local five-orbital
    fixed-(N_alpha,N_beta) Fock space (dimension at most 100) before selecting
    matrix elements. Applying a nonlinear function to P_selected S^2 P_selected
    would be wrong when the selected determinant space is not spin complete.

    Local spin rotations conserve each orbital's occupation. Their embedding
    in the global interleaved spin-orbital convention introduces no additional
    spectator-occupation signs. The untouched environment must agree exactly.
    """
    dets = _determinants(dets,n_orb)
    a,b,_ = _groups(n_orb,fe_a,fe_b)
    if len(a) != 5 or len(b) != 5:
        raise ValueError("The supplied Fe multiplet diagnostics require five d orbitals per Fe")
    if isinstance(diagnostics,(str,Path)):
        diagnostics = json.loads(Path(diagnostics).read_text(encoding="utf8"))
    components = {}
    for label, orbitals in (("A",a),("B",b)):
        spectra = diagnostics["Fe"][label][embedding]["by_N"]
        mask = sum(3 << (2*p) for p in orbitals)
        blocks = defaultdict(list)
        for index,d in enumerate(dets):
            local = sum(((d >> (2*p)) & 3) << (2*k) for k,p in enumerate(orbitals))
            na = sum((local >> (2*k)) & 1 for k in range(5))
            nb = sum((local >> (2*k+1)) & 1 for k in range(5))
            blocks[(d & ~mask,na,nb)].append((index,local))
        matrix = np.zeros((len(dets),len(dets)))
        cache = {}
        for (environment,na,nb), rows in blocks.items():
            key = (na,nb)
            if key not in cache:
                local_dets = [sum(1 << (2*p) for p in up)+sum(1 << (2*p+1) for p in down)
                              for up in combinations(range(5),na)
                              for down in combinations(range(5),nb)]
                local_s2 = spin_squared(local_dets,range(5),5)
                eigenvalues,eigenvectors = np.linalg.eigh(local_s2)
                twice_spin = np.rint(np.sqrt(1+4*eigenvalues)-1).astype(int)
                if np.max(np.abs(eigenvalues-.25*twice_spin*(twice_spin+2)),initial=0) > 1e-10:
                    raise AssertionError("Full local S squared has nonquantized eigenvalues")
                entry = spectra[str(na+nb)]
                ground = float(entry["lowest_Eh"])
                costs = {round(2*float(m["S"])):float(m["lowest_Eh"])-ground
                         for m in entry["multiplets"]}
                if min(costs.values()) < -1e-10:
                    raise ValueError("Inconsistent local ground and spin-sector energies")
                costs = {s:max(0.,e) for s,e in costs.items()}
                spectral = np.array([costs[int(s)] for s in twice_spin])
                cost_matrix = (eigenvectors*spectral)@eigenvectors.T
                cache[key] = ({d:i for i,d in enumerate(local_dets)},cost_matrix)
            lookup,cost_matrix = cache[key]
            global_index = [i for i,_ in rows]
            local_index = [lookup[d] for _,d in rows]
            matrix[np.ix_(global_index,global_index)] = cost_matrix[np.ix_(local_index,local_index)]
        components[label] = matrix
    result = components["A"]+components["B"]
    return (result,components) if return_components else result


def build_objective(H_selected, dets, weights, n_orb=20, fe_a=FE_A, fe_b=FE_B,
                    return_operators=False):
    """Return H_selected + sum_k lambda_k P_k, in the SAME determinant list.

    All lambda values use the units of H (Hartree for the molecular FCIDUMP).
    They are trial-design parameters; adding them changes the optimization
    objective. It does not change the Hamiltonian used for physical results.
    Positive coefficients are not imposed automatically on every channel.
    """
    dets = _determinants(dets, n_orb)
    h = np.asarray(H_selected)
    if h.shape != (len(dets), len(dets)) or not np.allclose(h, h.T.conj(), atol=1e-11):
        raise ValueError("H_selected must be a Hermitian matrix in determinant order")
    ops = penalty_operators(dets, n_orb, fe_a, fe_b)
    unknown = set(weights)-set(ops)
    if unknown:
        raise KeyError(f"Unknown penalty operator names {sorted(unknown)}")
    objective = h.astype(np.result_type(h.dtype, float), copy=True)
    for key, coefficient in weights.items():
        if not np.isfinite(coefficient) or not np.isreal(coefficient):
            raise ValueError("Penalty coefficients must be finite and real")
        objective += float(coefficient)*ops[key]
    return (objective, ops) if return_operators else objective


def selected_hamiltonian(h, eri, dets, ecore=0.0):
    """Real spin-free molecular H in a selected determinant basis.

    Uses all supplied one- and two-electron integrals, chemists' (pq|rs)
    convention. Pairwise Slater-Condon construction is a transparent O(M^2)
    reference, not a production large-M builder.
    """
    h, eri = np.asarray(h), np.asarray(eri)
    n = len(h)
    if h.shape != (n,n) or eri.shape != (n,)*4:
        raise ValueError("Invalid integral dimensions")
    if np.iscomplexobj(h) or np.iscomplexobj(eri):
        raise ValueError("This reference FCIDUMP builder requires real integrals")
    dets = _determinants(dets, n)
    if len({d.bit_count() for d in dets}) > 1:
        raise ValueError("All selected determinants must have the same electron count")
    occ = [[p for p in range(2*n) if (d >> p) & 1] for d in dets]
    def g(a,b,i,j):
        value = 0.0
        if a%2 == i%2 and b%2 == j%2:
            value += eri[a//2,i//2,b//2,j//2]
        if a%2 == j%2 and b%2 == i%2:
            value -= eri[a//2,j//2,b//2,i//2]
        return value
    matrix = np.zeros((len(dets),len(dets)))
    for ket, d in enumerate(dets):
        o = occ[ket]
        matrix[ket,ket] = ecore + sum(h[i//2,i//2] for i in o)
        matrix[ket,ket] += sum(g(i,j,i,j) for i,j in combinations(o,2))
        for bra in range(ket):
            b = dets[bra]
            removed = [i for i in o if not ((b >> i) & 1)]
            if len(removed) > 2:
                continue
            added = [a for a in occ[bra] if not ((d >> a) & 1)]
            if len(removed) == 1:
                i, a = removed[0], added[0]
                final, sign = _apply(d, [(i,False),(a,True)])
                value = h[a//2,i//2] if a%2 == i%2 else 0.0
                value += sum(g(a,j,i,j) for j in o if j != i)
            elif len(removed) == 2:
                i,j = removed
                a,b = added
                final, sign = _apply(d, [(i,False),(j,False),(b,True),(a,True)])
                value = g(a,b,i,j)
            else:
                raise AssertionError("Duplicate determinants should have been rejected")
            if final != dets[bra]:
                raise AssertionError("Incorrect excitation destination")
            matrix[bra,ket] = matrix[ket,bra] = sign*value
    return matrix


def self_test():
    # Include parent utilities solely as independent verification, not runtime deps.
    parent = str(Path(__file__).resolve().parent.parent)
    if parent not in sys.path:
        sys.path.insert(0, parent)
    from fe2s2_charge_model import formal_singlet, brute_action
    dimer = [(1 << 0)|(1 << 3), (1 << 1)|(1 << 2)]
    s2 = spin_squared(dimer, [0,1], 2)
    singlet, triplet = np.array([1.,-1.])/np.sqrt(2), np.ones(2)/np.sqrt(2)
    assert np.linalg.norm(s2@singlet) < 1e-13
    assert np.linalg.norm(s2@triplet-2*triplet) < 1e-13
    # This test would fail if S+ were projected into the fixed-Ms basis early.
    assert np.allclose(s2, [[1,1],[1,1]])
    state, lig = formal_singlet(20, FE_A, FE_B)
    dets = sorted(state)
    u = np.array([state[d] for d in dets])
    vals = charge_values(dets)
    ops = penalty_operators(dets)
    sa2, sb2 = spin_squared(dets, FE_A), spin_squared(dets, FE_B)
    st2 = spin_squared(dets, range(20))
    checks = dict(ionic_support=len(dets), norm_error=abs(u@u-1),
                  total_spin_residual=float(np.linalg.norm(st2@u)),
                  Fe_A_high_spin_residual=float(np.linalg.norm(sa2@u-8.75*u)),
                  Fe_B_high_spin_residual=float(np.linalg.norm(sb2@u-8.75*u)),
                  ionic_Hund_penalty=float(u@ops["D_Hund"]@u),
                  ionic_empty_orbital_count=float(u@ops["D_h"]@u))
    assert max(checks[k] for k in ("norm_error","total_spin_residual",
                                    "Fe_A_high_spin_residual","Fe_B_high_spin_residual")) < 1e-12
    assert abs(checks["ionic_Hund_penalty"]) < 1e-12
    assert checks["ionic_empty_orbital_count"] == 0
    # A one-magnon difference on A is local S=3/2, Ms=3/2. A symmetric
    # one-up state on B is S=5/2, Ms=-3/2. All Fe orbitals stay singly occupied.
    nonhund = np.zeros(len(dets)); lookup = {d:i for i,d in enumerate(dets)}
    mask_l = sum(3 << (2*p) for p in lig)
    for down_a, amplitude in zip(FE_A[:2], [1.,-1.]):
        for up_b in FE_B:
            d = mask_l
            for p in FE_A:
                d |= 1 << (2*p+int(p == down_a))
            for p in FE_B:
                d |= 1 << (2*p+int(p != up_b))
            nonhund[lookup[d]] += amplitude/np.sqrt(10)
    checks.update(nonHund_norm=float(nonhund@nonhund),
                  nonHund_D_h=float(nonhund@ops["D_h"]@nonhund),
                  nonHund_D_e_Fe=float(nonhund@ops["D_e_fe"]@nonhund),
                  nonHund_S_A_squared=float(nonhund@sa2@nonhund),
                  nonHund_S_B_squared=float(nonhund@sb2@nonhund),
                  nonHund_penalty=float(nonhund@ops["D_Hund"]@nonhund))
    assert abs(checks["nonHund_penalty"]-5) < 1e-12
    assert abs(checks["nonHund_S_A_squared"]-3.75) < 1e-12
    assert checks["nonHund_D_h"] == checks["nonHund_D_e_Fe"] == 0
    # Independent Hamiltonian verification on a complete toy Fock sector.
    rng = np.random.default_rng(20261124)
    n = 3; h = rng.normal(size=(n,n)); h = (h+h.T)/2
    chol = rng.normal(size=(4,n,n)); chol = (chol+chol.transpose(0,2,1))/2
    eri = np.einsum("xpq,xrs->pqrs",chol,chol)
    toy = [sum(1 << p for p in occ) for occ in combinations(range(2*n),3)]
    ht = selected_hamiltonian(h,eri,toy,.31)
    brute = np.zeros_like(ht)
    for j,d in enumerate(toy):
        action = brute_action({d:1.},h,eri,.31)
        brute[:,j] = [action.get(b,0.) for b in toy]
    checks["Slater_Condon_vs_second_quantization_max_error"] = float(np.max(np.abs(ht-brute)))
    assert checks["Slater_Condon_vs_second_quantization_max_error"] < 1e-12
    # Check hole identity away from the ionic support too, using random N=30 dets.
    random_dets = [sum(1 << int(i) for i in rng.choice(40,30,replace=False)) for _ in range(80)]
    cv = charge_values(random_dets)
    assert np.array_equal(cv["D_h"], cv["D_e_total"]-10)
    assert np.array_equal(cv["seniority"],30-2*cv["D_e_total"])
    original = ht.copy()
    obj, po = build_objective(ht,toy,{"D_Hund":.02,"D_h":.1},3,[0],[1],True)
    assert np.array_equal(ht,original)
    assert np.allclose(obj,ht+.02*po["D_Hund"]+.1*po["D_h"])
    checks.update(random_hole_identities_pass=True, objective_preserves_input_H=True,
                  selected_basis_size_preserved=True, all_checks_pass=True)
    return checks


def physical_spin_self_test(diagnostics):
    """Targeted check of multiplet-cost matrix and projection ordering."""
    parent = str(Path(__file__).resolve().parent.parent)
    if parent not in sys.path:
        sys.path.insert(0,parent)
    from fe2s2_charge_model import formal_singlet
    if isinstance(diagnostics,(str,Path)):
        diagnostics = json.loads(Path(diagnostics).read_text(encoding="utf8"))
    state,lig = formal_singlet(20,FE_A,FE_B)
    dets = sorted(state); u = np.array([state[d] for d in dets])
    cost,parts = physical_spin_penalty(dets,diagnostics,return_components=True)
    checks = dict(ionic_cost_Eh=float(u@cost@u),
                  minimum_selected_eigenvalue_Eh=float(np.linalg.eigvalsh(cost)[0]))
    assert abs(checks["ionic_cost_Eh"]) < 1e-12
    assert checks["minimum_selected_eigenvalue_Eh"] > -1e-12
    lookup = {d:i for i,d in enumerate(dets)}
    nonhund = np.zeros(len(dets)); ligand_mask = sum(3 << (2*p) for p in lig)
    for down_a,amplitude in zip(FE_A[:2],[1.,-1.]):
        for up_b in FE_B:
            d = ligand_mask
            for p in FE_A:
                d |= 1 << (2*p+int(p == down_a))
            for p in FE_B:
                d |= 1 << (2*p+int(p != up_b))
            nonhund[lookup[d]] = amplitude/np.sqrt(10)
    n5 = diagnostics["Fe"]["A"]["ionic_meanfield_spectra"]["by_N"]["5"]
    expected = next(m["lowest_Eh"] for m in n5["multiplets"] if m["S"] == 1.5)-n5["lowest_Eh"]
    measured = float(nonhund@cost@nonhund)
    checks.update(nonHund_expected_cost_Eh=expected,nonHund_measured_cost_Eh=measured,
                  nonHund_cost_eV=measured*27.211386246,
                  nonHund_cost_error_Eh=abs(measured-expected))
    assert abs(measured-expected) < 1e-12
    # Deliberately non-spin-complete selection. Build exact operator first,
    # then compress; compare to independently requesting only these rows.
    subset = np.array([0,8,17,28,37,44,62,83,108,134,178,201,239])
    compressed = physical_spin_penalty([dets[i] for i in subset],diagnostics)
    checks["nonspincomplete_compression_error_Eh"] = float(np.max(np.abs(compressed-cost[np.ix_(subset,subset)])))
    assert checks["nonspincomplete_compression_error_Eh"] < 1e-12
    # Include doubles and holes too: complete local N_A=4, Ms_A=0 block
    # with one frozen N_B=6 environment, then retain only a subset.
    environment = ligand_mask
    for k,p in enumerate(FE_B):
        environment |= (3 if k == 0 else (1 if k < 3 else 2)) << (2*p)
    block = [environment+sum(1 << (2*FE_A[p]) for p in up)+sum(1 << (2*FE_A[p]+1) for p in down)
             for up in combinations(range(5),2) for down in combinations(range(5),2)]
    full = physical_spin_penalty(block,diagnostics)
    indices = np.array([0,3,9,17,25,44,61,83,97])
    part = physical_spin_penalty([block[i] for i in indices],diagnostics)
    checks["N4_nonspincomplete_compression_error_Eh"] = float(np.max(np.abs(part-full[np.ix_(indices,indices)])))
    assert checks["N4_nonspincomplete_compression_error_Eh"] < 1e-12
    checks["all_physical_spin_checks_pass"] = True
    return checks


def example(path):
    parent = str(Path(__file__).resolve().parent.parent)
    if parent not in sys.path:
        sys.path.insert(0,parent)
    from fe2s2_charge_model import read_fcidump, formal_singlet
    h,eri,ecore,ne = read_fcidump(path)
    if len(h) != 20 or ne != 30:
        raise ValueError("Default example expects Fe2S2 CAS(30e,20o)")
    state,_ = formal_singlet(20,FE_A,FE_B)
    dets = sorted(state); u = np.array([state[d] for d in dets])
    H = selected_hamiltonian(h,eri,dets,ecore)
    objective = build_objective(H,dets,{"D_Hund":.02,"D_FeHole":.10,"D_h":.10})
    # This particular support contains the complete ten-spin, Ms=0 basis.
    # Restrict to exact total singlets. Without this step a different total-S
    # state can minimize this intentionally charge-frozen example Hamiltonian.
    total_s2 = spin_squared(dets,range(20))
    s2_values, s2_vectors = np.linalg.eigh(total_s2)
    singlets = s2_vectors[:,np.abs(s2_values) < 1e-9]
    energy,vecs = np.linalg.eigh(singlets.T@objective@singlets)
    c = singlets@vecs[:,0]
    return dict(determinants=len(dets), ionic_singlet_physical_energy=float(u@H@u),
                optimized_objective_energy=float(energy[0]),
                optimized_physical_energy=float(c@H@c),
                optimized_total_spin_squared=float(c@total_s2@c),
                singlet_directions=singlets.shape[1],
                retained_determinants=len(c),
                scope="API example in ionic single-occupancy support only; no ligand charge transfer, full TrimCI or AFQMC")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test",action="store_true")
    parser.add_argument("--example",action="store_true")
    parser.add_argument("--fcidump",type=Path)
    parser.add_argument("--spin-diagnostics",type=Path,
                        help="also validate the energy-weighted spin penalty from this JSON")
    parser.add_argument("--output",type=Path)
    args = parser.parse_args()
    result = {}
    if args.self_test:
        result["validation"] = self_test()
    if args.example:
        if not args.fcidump:
            parser.error("--example requires --fcidump")
        result["example"] = example(args.fcidump)
    if args.spin_diagnostics:
        result["physical_spin_validation"] = physical_spin_self_test(args.spin_diagnostics)
    if not result:
        parser.error("choose --self-test and/or --example")
    text = json.dumps(result,indent=2,allow_nan=False)+"\n"
    if args.output:
        args.output.write_text(text,encoding="utf8")
    print(text,end="")


if __name__ == "__main__":
    main()
