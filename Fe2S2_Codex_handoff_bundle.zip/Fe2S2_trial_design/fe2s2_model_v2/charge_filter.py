#!/usr/bin/env python3
"""Exact finite Fourier form of f(N_FeA,N_FeB), each shell with 0..10 electrons.

This is a trial representation, not an AFQMC driver. For each field k,l,
multiply every Fe-A orbital ROW of each spin's Slater orbital matrix by
exp(2*pi*i*k/11), and Fe-B rows by exp(2*pi*i*l/11). Multiply the resulting
determinant's coefficient by fft2(f)[k,l]/121. Summing all fields applies f.
All input CI coefficients are retained within each transformed group.

The 121-field bound applies ONLY to a function of these two total charges.
It does not include general orbital doublon or local-spin filters.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

FE_A = [2, 3, 4, 5, 6]
FE_B = [13, 14, 15, 16, 17]


def fourier_coefficients(charge_values):
    f = np.asarray(charge_values, dtype=complex)
    if f.shape != (11, 11) or not np.all(np.isfinite(f)):
        raise ValueError('Expected a finite 11-by-11 table for f(N_A,N_B).')
    return np.fft.fft2(f) / 121


def recover_charge_values(coefficients):
    c = np.asarray(coefficients, dtype=complex)
    if c.shape != (11, 11):
        raise ValueError('Expected 121 field coefficients.')
    return np.fft.ifft2(c) * 121


def transform_slater(orbitals, field_a, field_b, fe_a=FE_A, fe_b=FE_B):
    """Apply a one-body field to ket orbitals in the fixed FCIDUMP basis."""
    out = np.array(orbitals, dtype=complex, copy=True)
    if out.ndim != 2 or out.shape[0] != 20:
        raise ValueError('Expected a 20-by-Noccupied orbital matrix.')
    if not 0 <= field_a <= 10 or not 0 <= field_b <= 10:
        raise ValueError('Fourier field index must lie in 0..10.')
    out[fe_a, :] *= np.exp(2j * np.pi * field_a / 11)
    out[fe_b, :] *= np.exp(2j * np.pi * field_b / 11)
    return out


def validation():
    rng = np.random.default_rng(99415)
    f = rng.normal(size=(11, 11)) + 1j * rng.normal(size=(11, 11))
    c = fourier_coefficients(f)
    err = float(np.max(abs(recover_charge_values(c) - f)))
    # All charge eigenvalues, independently evaluate the explicit field sum.
    roots = np.exp(2j * np.pi * np.arange(11) / 11)
    explicit = np.empty_like(f)
    for na in range(11):
        for nb in range(11):
            explicit[na, nb] = np.einsum('k,kl,l->', roots**na, c, roots**nb)
    explicit_err = float(np.max(abs(explicit-f)))
    # Slater amplitudes on an occupation configuration get the predicted phase.
    up = np.linalg.qr(rng.normal(size=(20, 15)))[0]
    down = np.linalg.qr(rng.normal(size=(20, 15)))[0]
    occ_up = sorted(rng.choice(20, 15, replace=False).tolist())
    occ_down = sorted(rng.choice(20, 15, replace=False).tolist())
    n_a = sum(p in FE_A for p in occ_up + occ_down)
    n_b = sum(p in FE_B for p in occ_up + occ_down)
    old = np.linalg.det(up[occ_up]) * np.linalg.det(down[occ_down])
    new = 0j
    for k in range(11):
        for l in range(11):
            u = transform_slater(up, k, l)
            d = transform_slater(down, k, l)
            new += c[k,l]*np.linalg.det(u[occ_up])*np.linalg.det(d[occ_down])
    slater_err = float(abs(new/old - f[n_a,n_b]))
    if max(err, explicit_err, slater_err) > 1e-10:
        raise ArithmeticError('Finite Fourier filter failed its independent checks.')
    return dict(FFT_roundtrip_max=err, explicit_field_sum_max=explicit_err,
                Slater_amplitude_relative_factor_error=slater_err,
                maximum_number_of_one_body_fields=121)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ritz', type=Path, default=Path(__file__).resolve().parents[1]/'sector_ritz.json')
    parser.add_argument('--output', type=Path, default=Path(__file__).with_suffix('.json'))
    args = parser.parse_args()
    data = json.loads(args.ritz.read_text())
    mode = 'Fe_charge_pairs_symmetric'
    factors = data['results'][mode]['sector_amplitude_multipliers']
    f = np.zeros((11,11))
    for (a,b), factor in zip(data['sector_indices_N_FeA_N_FeB'], factors):
        f[a,b] = factor
    c = fourier_coefficients(f)
    output = dict(input_ritz_sha256=hashlib.sha256(args.ritz.read_bytes()).hexdigest(),
                  source_trial='stored singlet-projected UHF; NOT TrimCI',
                  sector_mode=mode, Fe_A_zero_based=FE_A, Fe_B_zero_based=FE_B,
                  table_f=f.tolist(), coefficient_real=c.real.tolist(),
                  coefficient_imag=c.imag.tolist(), checks=validation(),
                  scope='Exact representation of the stored charge-only filter. '
                        'Does not establish AFQMC speed, constraint bias, or trial accuracy. '
                        '121*M is an upper bound on transformed determinant terms for an M-term parent. '
                        'Parent spin projection, if present, also has its own representation cost.')
    args.output.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output['checks']))


if __name__ == '__main__':
    main()
