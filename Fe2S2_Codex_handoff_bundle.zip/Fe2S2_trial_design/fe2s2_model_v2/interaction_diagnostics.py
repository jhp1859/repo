#!/usr/bin/env python3
"""Local Fe-shell diagnostics for the published Li--Chan CAS(30e,20o).

No interactions are dropped in the molecular Hamiltonian. Local shell spectra
below are *diagnostics of a specified fragment embedding*, not energies of
the full molecular charge sectors. The script uses exact dense local Fock
matrices (at most 100 x 100 in the minimal-Ms block), NumPy, and SciPy.
"""
from __future__ import annotations

import argparse
from itertools import combinations
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from scipy.linalg import eigh

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fe2s2_charge_model import read_fcidump, act_on_state, brute_action

EV = 27.211386246
SHA256 = "95d8786af06eeea2107e19ffd98c66a6ca97fc8c9864175a4f6d64512b6f2df9"
FE = {"A": [2, 3, 4, 5, 6], "B": [13, 14, 15, 16, 17]}


def stats(x):
    x = np.asarray(x, dtype=float)
    return {"min": float(x.min()), "max": float(x.max()),
            "mean": float(x.mean()), "std": float(x.std()),
            "values": x.tolist()}


def minimal_ms_basis(norb, ne):
    na, nb = (ne + 1) // 2, ne // 2
    return [sum(1 << (2*p) for p in a) + sum(1 << (2*p+1) for p in b)
            for a in combinations(range(norb), na)
            for b in combinations(range(norb), nb)]


def one_move(det, annihilate, create):
    if not (det >> annihilate) & 1:
        return None
    sign = (-1) ** ((det & ((1 << annihilate) - 1)).bit_count())
    det ^= 1 << annihilate
    if (det >> create) & 1:
        return None
    sign *= (-1) ** ((det & ((1 << create) - 1)).bit_count())
    return det ^ (1 << create), sign


def spin_ladder(state, norb, plus):
    out = {}
    for det, c in state.items():
        for p in range(norb):
            res = one_move(det, 2*p+int(plus), 2*p+int(not plus))
            if res is not None:
                d, sg = res
                out[d] = out.get(d, 0.) + sg*c
    return out


def spin_squared(basis, norb, ne):
    lookup = {d: i for i, d in enumerate(basis)}
    ms = .5 * (ne % 2)
    mat = np.eye(len(basis))*ms*ms
    for j, d in enumerate(basis):
        for plus in (False, True):
            v = spin_ladder(spin_ladder({d: 1.}, norb, plus), norb, not plus)
            for dd, c in v.items():
                mat[lookup[dd], j] += .5*c
    return mat


def many_body_matrix(basis, h, g):
    lookup = {d: i for i, d in enumerate(basis)}
    out = np.zeros((len(basis), len(basis)))
    for j, d in enumerate(basis):
        ids, vals = act_on_state({d: 1.}, h, g, 0.)
        for dd, v in zip(ids, vals):
            if int(dd) not in lookup:
                if abs(v) > 1e-13:
                    raise RuntimeError("Spin-conserving local Hamiltonian left fixed N,Ms block")
            else:
                out[lookup[int(dd)], j] = v
    return out


def kanamori_tensor(n, u, v, j):
    out = np.zeros((n,)*4)
    for p in range(n):
        out[p,p,p,p] = u
        for q in range(n):
            if p == q:
                continue
            out[p,p,q,q] = v
            out[p,q,p,q] = j
            out[p,q,q,p] = j
    return out


def local_spectra(h, g, n_values=range(11)):
    result = {}
    checks = {"max_H_antihermiticity": 0., "max_H_S2_commutator": 0.,
              "max_eigen_residual": 0., "max_S2_quantization_error": 0.}
    for ne in n_values:
        basis = minimal_ms_basis(5, ne)
        H = many_body_matrix(basis, h, g)
        ss = spin_squared(basis, 5, ne)
        checks["max_H_antihermiticity"] = max(checks["max_H_antihermiticity"], float(np.max(np.abs(H-H.T))))
        checks["max_H_S2_commutator"] = max(checks["max_H_S2_commutator"], float(np.max(np.abs(H@ss-ss@H))))
        s2, vecs = eigh(ss)
        s = .5*(np.sqrt(1+4*np.maximum(s2,0))-1)
        s_quant = np.round(2*s)/2
        checks["max_S2_quantization_error"] = max(checks["max_S2_quantization_error"], float(np.max(np.abs(s-s_quant))))
        records = []
        doubles = np.array([sum(((d>>(2*p)) & 3) == 3 for p in range(5)) for d in basis])
        empties = np.array([sum(((d>>(2*p)) & 3) == 0 for p in range(5)) for d in basis])
        for spin in sorted(set(s_quant)):
            q = vecs[:, s_quant == spin]
            block = q.T@H@q
            ens, v = eigh(block)
            full_v = q@v[:,0]
            checks["max_eigen_residual"] = max(checks["max_eigen_residual"], float(np.linalg.norm(H@full_v-ens[0]*full_v)))
            records.append({"S": float(spin), "multiplet_count": q.shape[1],
                            "lowest_Eh": float(ens[0]), "lowest_three_Eh": ens[:3].tolist(),
                            "mean_orbital_double_occupancy": float(full_v**2@doubles),
                            "mean_empty_orbitals_hole_doublons": float(full_v**2@empties),
                            "mean_excess_double_occupancy_above_max_Nminus5_0":float(full_v**2@doubles-max(ne-5,0))})
        emin = min(r["lowest_Eh"] for r in records)
        emaxspin = records[-1]["lowest_Eh"]
        for r in records:
            r["gap_from_charge_ground_eV"] = (r["lowest_Eh"]-emin)*EV
            r["gap_from_maximum_spin_eV"] = (r["lowest_Eh"]-emaxspin)*EV
        result[str(ne)] = {"N": ne, "minimal_Ms_dimension": len(basis),
                           "lowest_Eh": emin, "ground_S": min(records,key=lambda r:r['lowest_Eh'])['S'],
                           "multiplets": records}
    for ne in range(1,10):
        if all(str(k) in result for k in (ne-1,ne,ne+1)):
            result[str(ne)]["local_charge_curvature_eV"] = EV*(result[str(ne-1)]["lowest_Eh"] + result[str(ne+1)]["lowest_Eh"]-2*result[str(ne)]["lowest_Eh"])
    return {"by_N": result, "checks": checks}


def main(path):
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    if sha != SHA256:
        raise ValueError("Input is not the intended original public FCIDUMP")
    h,g,core,ne = read_fcidump(path)
    if (len(h),ne) != (20,30):
        raise ValueError("Expected CAS(30e,20o)")
    lig = sorted(set(range(20))-set(FE['A'])-set(FE['B']))
    result = {"input_sha256": sha, "input_ECORE_Eh": core,
              "convention": "Real spatial orbitals, chemist ERI (pq|rs). U_m=(mm|mm); V_mn=(mm|nn); J_mn=(mn|nm). These are integral magnitudes, not molecular charge-transfer gaps.",
              "orbitals_one_based": {k:[i+1 for i in v] for k,v in FE.items()} | {"ligand":[i+1 for i in lig]},
              "local_embedding_scope": "Local Fe five-orbital Hamiltonians use complete on-Fe ERI. Frozen ligand potential has 2J-K from all ten doubly occupied ligand orbitals. Optional other-Fe ionic mean-field bath has one electron per spatial orbital, spin averaged. No interfragment correlations or ligand fluctuations are included in these LOCAL spectra. Energies omit environment constants and cannot be compared across embeddings as molecular energies.",
              "Fe": {}}
    for name, ix in FE.items():
        other = FE['B' if name == 'A' else 'A']
        u = np.array([g[m,m,m,m] for m in ix])
        v = np.array([g[m,m,n,n] for m,n in combinations(ix,2)])
        j = np.array([g[m,n,n,m] for m,n in combinations(ix,2)])
        local_g = g[np.ix_(ix,ix,ix,ix)]
        h0 = h[np.ix_(ix,ix)].copy()
        hlig = h0 + 2*np.einsum('pqii->pq',g[np.ix_(ix,ix,lig,lig)])-np.einsum('piiq->pq',g[np.ix_(ix,lig,lig,ix)])
        hionic = hlig + np.einsum('pqii->pq',g[np.ix_(ix,ix,other,other)])-.5*np.einsum('piiq->pq',g[np.ix_(ix,other,other,ix)])
        kfree = kanamori_tensor(5,u.mean(),v.mean(),j.mean())
        krot = kanamori_tensor(5,u.mean(),u.mean()-2*j.mean(),j.mean())
        vals = {"U_eV": stats(EV*u), "V_eV": stats(EV*v), "J_eV": stats(EV*j),
                "mean_V_minus_mean_U_plus_2mean_J_eV": float(EV*(v.mean()-u.mean()+2*j.mean())),
                "local_tensor_relative_frobenius_error_three_parameter_Kanamori": float(np.linalg.norm(local_g-kfree)/np.linalg.norm(local_g)),
                "local_tensor_relative_frobenius_error_rotational_Uminus2J_Kanamori": float(np.linalg.norm(local_g-krot)/np.linalg.norm(local_g)),
                "h_local_Eh": h0.tolist(), "h_ligand_closed_Eh": hlig.tolist(),
                "h_ionic_meanfield_Eh": hionic.tolist(),
                "ligand_closed_spectra": local_spectra(hlig,local_g),
                "ionic_meanfield_spectra": local_spectra(hionic,local_g)}
        for nm,hh in [('bare_active_h',h0),('ligand_closed_h',hlig),('ionic_meanfield_h',hionic)]:
            eig=np.linalg.eigvalsh(hh)
            vals[nm+'_eigenvalue_span_eV']=float(EV*(eig[-1]-eig[0]))
        result['Fe'][name]=vals
    a,b=FE['A'],FE['B']
    result['inter_Fe'] = {'direct_Coulomb_eV':stats([EV*g[p,p,q,q] for p in a for q in b]),
                          'exchange_eV':stats([EV*g[p,q,q,p] for p in a for q in b]),
                          'bare_hopping_abs_eV':stats([EV*abs(h[p,q]) for p in a for q in b])}
    result['Fe_ligand'] = {'bare_hopping_abs_eV':stats([EV*abs(h[p,q]) for p in a+b for q in lig])}
    # Independent second-quantized action validates the Slater--Condon path
    # on one actual five-orbital determinant, not on the same matrix code.
    ix=a; hh=np.asarray(result['Fe']['A']['h_ionic_meanfield_Eh']); gg=g[np.ix_(ix,ix,ix,ix)]
    d=minimal_ms_basis(5,5)[31]
    ids,vals=act_on_state({d:1.},hh,gg,0.)
    lhs={int(k):float(v) for k,v in zip(ids,vals)}
    rhs=brute_action({d:1.},hh,gg,0.)
    result['independent_action_check_max_Eh']=max(abs(lhs.get(k,0)-rhs.get(k,0)) for k in lhs.keys()|rhs.keys())
    return result


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('fcidump',type=Path)
    parser.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'))
    args=parser.parse_args()
    data=main(args.fcidump)
    args.output.write_text(json.dumps(data,indent=2)+'\n')
    for name,fe in data['Fe'].items():
        print(name,'U,V,J means eV',fe['U_eV']['mean'],fe['V_eV']['mean'],fe['J_eV']['mean'])
        for emb in ('ligand_closed_spectra','ionic_meanfield_spectra'):
            print(emb)
            for n,r in fe[emb]['by_N'].items():
                print(n,[(m['S'],round(m['gap_from_charge_ground_eV'],6)) for m in r['multiplets']])
    print('checks independent action',data['independent_action_check_max_Eh'])
