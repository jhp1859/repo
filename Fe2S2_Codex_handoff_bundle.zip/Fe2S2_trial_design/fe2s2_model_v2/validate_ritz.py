"""Independent small-matrix audit of the saved Fe2S2 charge-sector pilot.

This program reuses saved full-Hamiltonian matrix elements, rather than
independently recomputing molecular integrals or the projected wavefunction.
It checks the Ritz algebra and evaluates candidate charge correlators.
It does not run TrimCI or AFQMC.

Run from any directory with Python, NumPy and SciPy:
  python fe2s2_model_v2/validate_ritz.py
"""
from pathlib import Path
import hashlib
import json

import numpy as np
from numpy.polynomial import Polynomial
from scipy.linalg import eigh
from scipy.optimize import minimize

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / "sector_ritz.npz"
REPORT = Path(__file__).with_suffix(".json")


def main():
    data = np.load(SOURCE)
    charges = data["charges"]
    p_raw = data["p"]
    matrix = data["H"]
    reference = float(data["reference"])
    source_json = json.loads((ROOT / "sector_ritz.json").read_text())
    a, b = charges.T
    h = a + b - 10
    m = np.abs(a - b)
    bad = np.maximum(0, 5 - a) + np.maximum(0, 5 - b)
    r = (np.abs(a - 5) + np.abs(b - 5) + h) // 2
    assert np.all(r == h + bad)
    assert np.all(2 * bad == np.maximum(0, m - h))
    # Two negative weights of order 1e-18 are Fourier-roundoff residues.
    p = np.maximum(p_raw, 0.0)
    p /= p.sum()
    matrix = (matrix + matrix.T) / 2
    shift = matrix - reference * np.diag(p)

    checks = {
        "input_npz_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        "input_FCIDUMP_sha256_from_metadata": source_json["sha256"],
        "weight_sum_error_before_clipping": float(abs(p_raw.sum() - 1)),
        "minimum_weight_before_clipping": float(p_raw.min()),
        "clipped_negative_weight_mass": float(-p_raw[p_raw < 0].sum()),
        "matrix_Hermiticity_error_Eh": float(np.max(abs(data["H"] - data["H"].T))),
        "full_energy_closure_error_Eh": float(abs(matrix.sum() - reference)),
        "stored_source_projection_checks": source_json["checks"],
    }

    def details(amplitude):
        norm = p @ amplitude**2
        weight = p * amplitude**2 / norm
        energy = reference + amplitude @ shift @ amplitude / norm
        return {
            "energy_Eh": float(energy),
            "gain_from_singlet_UHF_mEh": float((reference - energy) * 1000),
            "D_bad_expectation": float(weight @ bad),
            "probability_any_Fe_below_d5": float(weight[bad > 0].sum()),
            "ligand_hole_expectation": float(weight @ h),
            "imbalance_expectation": float(weight @ m),
            "p_d5_d5": float(weight[(a == 5) & (b == 5)].sum()),
            "p_d6_d6": float(weight[(a == 6) & (b == 6)].sum()),
            "p_single_MMCT": float(weight[((a == 4) & (b == 6)) | ((a == 6) & (b == 4))].sum()),
            "norm_error": float(abs(weight.sum() - 1)),
        }

    # Enumerate all stationary points of the exact rational polynomial on
    # q in [0,1], including its two endpoints. Here q = exp(-lambda).
    def suppress_one(feature):
        power = feature.astype(int)
        numerator = Polynomial(np.bincount((power[:, None] + power[None, :]).ravel(),
                                           weights=shift.ravel()))
        denominator = Polynomial(np.bincount(2 * power, weights=p))
        derivative = numerator.deriv() * denominator - numerator * denominator.deriv()
        roots = derivative.roots()
        qs = [0.0, 1.0] + [float(x.real) for x in roots
                           if abs(x.imag) < 1e-8 and 0 < x.real < 1]
        q = min(qs, key=lambda value: numerator(value) / denominator(value))
        result = details(q**power)
        result.update({"q": q, "lambda": float(-np.log(q)) if q > 0 else "infinity",
                       "stationary_points_and_endpoints_tested": len(qs)})
        return result

    def fit_features(features, names, bounds):
        features = np.asarray(features).T

        def objective(parameter):
            exponent = -features @ parameter
            amplitude = np.exp(exponent - exponent.max())
            norm = p @ amplitude**2
            action = shift @ amplitude
            energy = amplitude @ action / norm
            gradient = -2 * ((amplitude * (action - energy * p * amplitude)) @ features) / norm
            return energy, gradient

        starts = [np.zeros(len(names))]
        if len(names) == 2:
            starts.extend([np.array([-.1, .3]), np.array([.1, .1])])
        fits = [minimize(objective, start, method="L-BFGS-B", jac=True,
                         bounds=bounds, options={"ftol": 1e-15, "gtol": 1e-11, "maxiter": 1000})
                for start in starts]
        fit = min(fits, key=lambda item: item.fun)
        exponent = -features @ fit.x
        result = details(np.exp(exponent - exponent.max()))
        result.update({"parameters": dict(zip(names, fit.x.tolist())),
                       "bounds": bounds, "optimizer_success": bool(fit.success),
                       "unconstrained_gradient_norm_Eh": float(np.linalg.norm(fit.jac)),
                       "multistart_energy_range_Eh": float(np.ptp([f.fun for f in fits]))})
        return result

    ritz_rechecks = {}
    groupings = {
        "charge_transfer_count": r.tolist(),
        "ligand_holes": h.tolist(),
        "Fe_charge_pairs_symmetric": [tuple(sorted(ab)) for ab in charges.tolist()],
        "Fe_charge_pairs_resolved": [tuple(ab) for ab in charges.tolist()],
        "Fe_below_d5_count": bad.tolist(),
    }
    for name, original_labels in groupings.items():
        labels = original_labels.copy()
        for group in set(labels):
            selected = np.array([label == group for label in labels])
            if p[selected].sum() < 1e-6:
                labels = ["remainder" if (old == group) else old for old in labels]
        unique = list(dict.fromkeys(labels))
        mask = np.array([[float(label == group) for group in unique] for label in labels])
        metric = np.diag(mask.T @ p)
        reduced_h = mask.T @ matrix @ mask
        eigenvalues, vectors = eigh(reduced_h, metric)
        amplitude = mask @ vectors[:, 0]
        out = details(amplitude)
        out["directions"] = len(unique)
        out["generalized_eigenpair_residual_Eh"] = float(np.linalg.norm(
            reduced_h @ vectors[:, 0] - eigenvalues[0] * metric @ vectors[:, 0]))
        out["energy_diagonalization_vs_Rayleigh_Eh"] = float(abs(out["energy_Eh"] - eigenvalues[0]))
        if name in source_json["results"]:
            out["difference_from_saved_Ritz_energy_Eh"] = float(out["energy_Eh"] - source_json["results"][name]["energy_Eh"])
        ritz_rechecks[name] = out

    out = {
        "scope": "New independent small-matrix Ritz algebra checks and correlator optimizations using previously computed K and p. No new full-CAS, TrimCI or AFQMC calculation.",
        "checks": checks,
        "features": {
            "h": "N_FeA + N_FeB - 10 = 20 - N_ligand",
            "m": "abs(N_FeA - N_FeB)",
            "D_bad": "max(0, 5-N_FeA) + max(0, 5-N_FeB)",
            "r": "h + D_bad",
            "interpretation": "D_bad counts Fe-shell electron deficits below d5 and allows ligand-to-Fe transfer without automatic penalty. It is a diagnostic candidate, not an exact energetic classification or an independently additive Coulomb interaction.",
        },
        "starting_trial": details(np.ones_like(p)),
        "correlators": {
            "exp_minus_lambda_r": suppress_one(r),
            "exp_minus_lambda_D_bad": suppress_one(bad),
            "exp_minus_lambda_m": suppress_one(m),
            "exp_minus_lambda_h_h_minus_lambda_m_m": fit_features([h, m], ["lambda_h", "lambda_m"], [(-.4, 2), (-.4, 2)]),
            "exp_minus_lambda_h_h_minus_lambda_bad_D_bad": fit_features([h, bad], ["lambda_h", "lambda_bad"], [(-.4, 2), (0, 4)]),
            "exp_minus_lambda_h_h_minus_lambda_m_m_minus_lambda_bad_D_bad": fit_features([h, m, bad], ["lambda_h", "lambda_m", "lambda_bad"], [(-.4, 2), (-.4, 2), (0, 4)]),
        },
        "Ritz_rechecks": ritz_rechecks,
        "audit_limits": [
            "An internally consistent K,p audit does not independently validate their molecular integral contraction. The existing UHF energy closure, Hermiticity, spin projection conventions and block residues support but do not replace an independent full contraction.",
            "Eleven charge Fourier points exactly resolve integer Fe occupations 0 through 10. Six Gauss-Legendre nodes exactly integrate spin projection for M_S=0 and S_max=5 in 30 electrons and 20 orbitals; charge projectors and spin-free H commute with total spin.",
            "Closed-ligand energies are minima in projected fixed-charge blocks. One-hole energies are restricted variational upper bounds to their full charge-block minima and are not molecular spectroscopic excitation energies.",
            "d4-d6 being costly in a ligand-closed block supports testing D_bad but does not establish that every D_bad-positive state lies above every D_bad-zero state when ligand holes vary.",
            "For this fixed N=30, L=20 space, D_hole=sum_p(1-n_p_up)(1-n_p_down)=D_electron-10. This nonnegative empty-orbital count is an alternative microscopic diagnostic that can allow LMCT while penalizing orbital charge defects. It is not equal to D_bad and its projected matrix elements cannot be recovered from charge K,p alone.",
            "Ritz reweighting fixes each sector's internal direction and optimizes only amplitudes. It does not implement the desired low-sector directional TrimCI search.",
            "Within an identical fixed determinant subspace, full-H Ritz already minimizes original energy. H+mu*D can guide selection or constraint and change trial structure; it cannot beat full-H Ritz on the same subspace by variational energy alone.",
            "The public DMRG energy is a reference for this chosen CAS Hamiltonian; molecular chemical accuracy also depends on active space, orbitals, basis, and omitted correlation.",
            "No AFQMC energy improvement or scalable correlated-trial evaluator is established by these results."
        ],
    }
    REPORT.write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps({"path": str(REPORT), "checks": checks,
                      "correlators": out["correlators"], "Ritz_rechecks": ritz_rechecks}, indent=2))


if __name__ == "__main__":
    main()
