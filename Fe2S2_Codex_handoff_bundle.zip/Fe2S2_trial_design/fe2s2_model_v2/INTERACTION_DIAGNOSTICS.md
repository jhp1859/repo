# 실제 적분에서 얻은 Fe 국소 상호작용 진단

## 계산 범위

Li–Chan의 공개 CAS(30e,20o) FCIDUMP를 새로 내려받아 SHA-256을 확인하고 계산했다. Fe A는 입력의 1-based 3–7번, Fe B는 14–18번이다. 나머지 10개 궤도를 리간드 그룹으로 분류한다. 원래 분자 해밀토니안의 적분은 변경하지 않는다.

`interaction_diagnostics.py`는 5개 Fe 궤도의 국소 Fock 공간을 정확 대각화한다. 각 전자 수 N에서 최소 |M_S| 블록을 사용하고 S²의 고유공간으로 분해한다. 가장 큰 행렬은 100×100이다. 모든 N=0,…,10을 계산하며, 전체 분자의 FCI 또는 AFQMC는 수행하지 않는다.

## 실제 적분의 크기

실수 공간궤도의 chemist convention에서 U_m=(mm|mm), V_mn=(mm|nn), J_mn=(mn|nm)로 정의한다. 아래는 eV 단위 평균이다.

| 양 | Fe A | Fe B |
|---|---:|---:|
| 궤도 내 U | 21.8887 | 21.8861 |
| 다른 궤도 직접 Coulomb V | 20.3088 | 20.3080 |
| 다른 궤도 교환 J | 0.7525 | 0.7531 |

두 Fe 사이 직접 Coulomb 적분의 평균은 5.14993 eV, 교환 적분의 평균은 0.004763 eV이다. 이 수치들은 분자 전하이동 여기 에너지와 구별해야 한다. 실제 전하 비용에는 일전자 에너지, 다른 원자와의 Coulomb 상호작용, 스크리닝과 혼성이 함께 들어간다.

평균 V는 평균 U−2J와 약 0.075 eV 이내로 일치한다. 그러나 개별 U는 전체 Fe 궤도에서 약 19.35–23.32 eV 범위이고, 평균 U,V,J만 사용하는 Kanamori 텐서의 상대 Frobenius 오차는 약 6.4%다. 큰 Coulomb 적분이 이 노름을 지배하므로 이 6.4%만으로 저에너지 정확도를 평가할 수 없다. 정밀 계산에서는 원래 적분을 유지해야 한다.

## 국소 multiplet 비용

두 가지 명시적 embedding을 비교한다.

1. **닫힌 리간드 embedding**은 10개 리간드 궤도를 이중점유로 고정해 2J−K 일전자 퍼텐셜을 Fe에 더한다. 다른 Fe는 이 국소 진단에서 제외한다.
2. **이온성 평균장 embedding**은 여기에 다른 Fe의 각 d 궤도가 전자 하나를 갖는 스핀 평균 밀도를 더한다. 각 스핀의 점유는 1/2이다. 다른 Fe와의 스핀 얽힘은 포함하지 않는다.

각 embedding의 Fe 국소 Hamiltonian은 완전한 궤도 의존 ERI를 사용한다. 모든 N에서 최대스핀 상태가 가장 낮았다. 이온성 평균장 embedding에서 얻은 대표적인 비용은 다음과 같다.

| 전자 수와 스핀 변화 | Fe A 비용 (eV) | Fe B 비용 (eV) |
|---|---:|---:|
| d⁴, S=2 → S=1 | 1.7276 | 1.7471 |
| d⁵, S=5/2 → S=3/2 | 2.4234 | 2.4045 |
| d⁵, S=5/2 → S=1/2 | 3.9020 | 3.8907 |
| d⁶, S=2 → S=1 | 2.4426 | 2.4439 |
| d⁷, S=3/2 → S=1/2 | 2.1050 | 2.1093 |

닫힌 리간드만 넣으면 d⁵의 첫 스핀 비용은 0.7616 eV와 0.7187 eV로 바뀐다. 따라서 위 숫자는 지정한 환경에서의 국소 비용이다. 완전한 분자의 자성 여기 에너지, 실제 전하 sector 간 gap, 또는 경험적 J_AB로 읽으면 안 된다.

## 일반화된 penalty의 구성

전자 수마다 같은 기준으로 double occupancy를 억제하면 물리적으로 필요한 d⁶,d⁷ 상태를 과도하게 억제할 수 있다. 최대스핀 d⁵는 double 0개, d⁶는 1개, d⁷는 2개를 갖지만, 세 경우 모두 빈 Fe 궤도는 0개다. 반면 최대스핀 d⁴는 double 0개와 빈 궤도 1개를 갖는다.

전하를 고정한 국소 spin 비용은 다음의 양의 연산자로 정의할 수 있다.

\[
C_I^{\rm spin}=\sum_{N,S}[\epsilon_{I,\min}(N,S)-\epsilon_{I,\min}(N)]P_{I,N,S}.
\]

이 연산자는 국소 N_I와 S_I²로 분류되며, 궤도 내 multiplet excitation은 따로 구별하지 않는다. 더 완전한 국소 에너지 penalty는

\[
C_I^{\rm local}=H_I^{\rm emb}-\sum_N\epsilon_{I,\min}(N)P_{I,N}\succeq0
\]

이다. JSON에 모든 N의 기준 에너지가 들어 있어 원래 국소 적분과 함께 이 연산자를 재구성할 수 있다. 이것은 선택한 embedding에 의존하는 trial 설계용 연산자다. 전하 이동 비용은 별도로 완전한 분자 H의 charge-block 검사에서 결정해야 한다.

U D_double와 V N(N−1)/2 같은 항은 독립적인 물리적 벌점으로 중복해서 더하면 안 된다. 항등식

\[
\sum_{m<n}n_mn_n=N(N-1)/2-D_{\rm double}
\]

때문에 같은 Coulomb 비용을 여러 방식으로 세고 있을 수 있다. Trial 목적함수에 여러 penalty를 쓰는 경우에는 해당 계수들을 물리적 U의 복사본으로 해석하지 않고 별도의 알고리즘 매개변수로 기록해야 한다.

## 홀 doublon과 seniority

이 CAS는 20개 공간궤도에 30개 전자가 있으므로

\[
D_{\rm hole}=\sum_p(1-n_{p\uparrow})(1-n_{p\downarrow})
=D_{\rm electron}-10.
\]

즉 피할 수 없는 10개의 전자 double을 제외한 수를 빈 궤도 수로 센다. 국소화된 궤도의 대표 점유배치에서는 d⁵d⁵+닫힌 리간드, d⁶d⁵+서로 다른 리간드 홀, d⁶d⁶+서로 다른 두 리간드 홀이 모두 D_hole=0에 들어갈 수 있다. d⁴d⁶은 최소 한 빈 Fe 궤도를 요구해 D_hole≥1이다. 실제 파동함수는 이러한 배치들의 중첩이다.

같은 궤도 정의의 seniority Ω=Σ_p[n_p−2n_{p↑}n_{p↓}]에 대해서 Ω=10−2D_hole이다. 이 연산자들은 궤도 회전에 의존한다. 궤도 그룹별 N_I,S_I²와 달리 그룹 내부 회전에도 D_hole의 의미가 바뀔 수 있다. 따라서 기존 국소화 궤도를 고정해 비교해야 한다.

## 검산과 재현

H의 Hermitian 검사는 정확히 0, [H,S²] 최대 원소는 약 7.1×10⁻¹⁵ Ha, 가장 낮은 spin-block 고유벡터의 H 잔차는 7.5×10⁻¹⁴ Ha 이하이다. 별도로 원시 2차양자화 생성·소멸 연산자를 적용한 결과는 Slater–Condon 구현과 5.3×10⁻¹⁵ Ha 이내로 일치했다.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python fe2s2_model_v2/interaction_diagnostics.py fe2s2_model_v2/FCIDUMP
```

정확한 입력 checksum, 모든 적분 통계, embedding 행렬, 전자 수·스핀별 에너지와 double/empty 기대값은 `interaction_diagnostics.json`에 있다.
