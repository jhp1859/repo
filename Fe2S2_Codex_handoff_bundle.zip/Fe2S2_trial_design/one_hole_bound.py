"""Variational singlet bound in a charge block with one ligand hole.

Usage: OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python one_hole_bound.py FCIDUMP
The frozen ligand orbitals are exactly doubly occupied in this restricted
variational subspace. A hole can use only the one user-specified orbital.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from pyscf import ao2mo, fci
from pyscf.tools import fcidump
from scipy.sparse.linalg import LinearOperator, eigsh

from closed_ligand import FE_A, FE_B, SOURCE_SHA256


def one_hole_block(data, hole, charge, seed):
    active = FE_A + FE_B + [hole]
    ligand_core = sorted(set(range(20)) - set(active))
    n = len(active)
    ne = (6, 6)
    eri = ao2mo.restore(1, data['H2'], 20)
    h = data['H1']
    ix = np.ix_
    cccc = eri[ix(ligand_core, ligand_core, ligand_core, ligand_core)]
    offset = data.get('ECORE', 0.) + 2*h[ligand_core, ligand_core].sum()
    offset += 2*np.einsum('iijj->', cccc) - np.einsum('ijji->', cccc)
    h_eff = h[ix(active, active)] + 2*np.einsum('pqii->pq', eri[ix(active, active, ligand_core, ligand_core)])
    h_eff -= np.einsum('piiq->pq', eri[ix(active, ligand_core, ligand_core, active)])
    g_eff = eri[ix(active, active, active, active)]
    f = fci.direct_spin1
    h2 = f.absorb_h1e(h_eff, g_eff, n, ne, .5)
    links = fci.cistring.gen_linkstr_index_trilidx(range(n), ne[0])
    strings = fci.cistring.make_strings(range(n), ne[0])
    fe_a_count = np.array([(int(s) & 31).bit_count() for s in strings])
    ligand_occ = (strings >> 10) & 1
    mask = ((fe_a_count[:, None] + fe_a_count[None, :] == charge)
            & (ligand_occ[:, None] + ligand_occ[None, :] == 1))
    locations = np.flatnonzero(mask)
    size = len(locations)
    penalty = .25

    def apply(vector):
        whole = np.zeros(mask.shape)
        whole.flat[locations] = vector
        hv = f.contract_2e(h2, whole, n, ne, (links, links)).ravel()[locations]
        ss = fci.spin_op.contract_ss(whole, n, ne).ravel()[locations]
        return hv, ss

    def matvec(vector):
        hv, ss = apply(vector)
        return hv + penalty * ss

    rng = np.random.default_rng(seed)
    op = LinearOperator((size, size), matvec=matvec, dtype=float)
    _, vectors = eigsh(op, k=1, which='SA', tol=5e-11, v0=rng.normal(size=size), maxiter=1500)
    vec = vectors[:, 0]
    hv, ss = apply(vec)
    energy = vec @ hv
    residual = float(np.linalg.norm(hv - energy*vec))
    s_norm = float(np.linalg.norm(ss))
    if s_norm > 1e-6 or residual > 1e-7:
        raise RuntimeError(f'Spin or eigenpair convergence failure: {residual}, {s_norm}')
    return dict(charge=[charge, 11-charge, 19], hole_orbital_one_based=hole+1,
                restricted_ms0_dimension=size, energy_upper_bound_Eh=float(energy+offset),
                restricted_residual_Eh=residual, s_squared=float(vec @ ss),
                s_squared_vector_norm=s_norm, spin_penalty_Eh=penalty)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('fcidump', type=Path)
    p.add_argument('--hole', type=int, default=[8, 11], nargs='+',
                   help='One-based active ligand orbital indices to try independently')
    p.add_argument('--charge-a', type=int, choices=(5, 6), default=6)
    p.add_argument('--output', type=Path, default=Path('one_hole_bound.json'))
    args = p.parse_args()
    if hashlib.sha256(args.fcidump.read_bytes()).hexdigest() != SOURCE_SHA256:
        p.error('Unexpected FCIDUMP; check the orbital ordering.')
    data = fcidump.read(str(args.fcidump), verbose=False)
    ligand_set = set(range(20)) - set(FE_A + FE_B)
    holes = args.hole
    if not all(hole-1 in ligand_set for hole in holes):
        p.error('Hole orbitals must be in the ligand set.')
    rng_seed = 8942
    result = dict(input_sha256=SOURCE_SHA256, rng_seed=rng_seed,
                  scope='Spin-pure variational upper bounds for the full fixed-charge block. Each row constrains the hole to one specified ligand orbital, with the other nine doubly occupied. Energies use the input Hamiltonian including its file ECORE.',
                  blocks=[])
    for hole in holes:
        row = one_hole_block(data, hole-1, args.charge_a, rng_seed)
        result['blocks'].append(row)
        print(json.dumps(row), flush=True)
        args.output.write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
