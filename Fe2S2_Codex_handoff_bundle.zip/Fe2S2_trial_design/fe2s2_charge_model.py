#!/usr/bin/env python3
"""Charge-resolved H|u> for the formal high-spin Fe(III)-Fe(III) singlet.

Real, spin-free FCIDUMP in chemist's (pq|rs) convention; requires NumPy.
Give the two Fe 3d subspaces as comma-separated, ONE-based spatial-orbital
indices in the localized FCIDUMP. All remaining orbitals are filled ligands.
For an atomic-character or localization assignment use the matching orbitals
and metadata: integral magnitudes alone do not identify the Fe centers.
The matrix elements are in the input energy units (normally Hartree).
"""
import argparse
from itertools import combinations, product
import json
import math
from pathlib import Path
import re
import tempfile

import numpy as np


def read_fcidump(path):
    """Read restricted, real, spin-free FCIDUMP; restore eightfold ERI symmetry."""
    with Path(path).open() as stream:
        header_lines = []
        for line in stream:
            line = line.split("!")[0].split("#")[0]
            header_lines.append(line)
            if re.search(r"&END|\$END|/", line, re.I):
                break
        else:
            raise ValueError("FCIDUMP lacks a terminated namelist header")
        header = " ".join(header_lines)
        if re.search(r"\bI?UHF\s*=\s*(?:[1-9]|\.?T)", header, re.I):
            raise ValueError("An unrestricted FCIDUMP requires a different reader")
        def integer(name):
            m = re.search(r"\b" + name + r"\s*=\s*([-+]?\d+)", header, re.I)
            if not m:
                raise ValueError(f"Missing {name} in FCIDUMP header")
            return int(m.group(1))
        n, ne = integer("NORB"), integer("NELEC")
        if not 1 <= n <= 31:
            raise ValueError("Implementation supports 1 to 31 spatial orbitals")
        one = np.zeros((n, n))
        eri = np.zeros((n,) * 4)
        ecore = 0.0
        for line in stream:
            f = line.split("!")[0].split("#")[0].split()
            if not f:
                continue
            if len(f) != 5:
                raise ValueError(f"Unrecognized FCIDUMP record: {line.rstrip()}")
            value = float(f[0].replace("d", "e").replace("D", "E"))
            indices = list(map(int, f[1:]))
            if any(k < 0 or k > n for k in indices) or not math.isfinite(value):
                raise ValueError(f"Invalid FCIDUMP record: {line.rstrip()}")
            i, j, k, l = indices
            if i == j == k == l == 0:
                ecore = value
            elif i > 0 and j == k == l == 0:
                continue  # optional orbital energies, not Hamiltonian terms
            elif i > 0 and j > 0 and k == l == 0:
                one[i-1, j-1] = one[j-1, i-1] = value
            elif min(indices) > 0:
                p, q, r, s = [u - 1 for u in indices]
                for a, b in ((p, q), (q, p)):
                    for c, d in ((r, s), (s, r)):
                        eri[a, b, c, d] = eri[c, d, a, b] = value
            else:
                raise ValueError(f"Unrecognized FCIDUMP record: {line.rstrip()}")
        return one, eri, ecore, ne


def formal_singlet(n, fe_a, fe_b):
    """Equal-size, half-filled High-spin Fe subspaces coupled to a singlet."""
    a, b = list(fe_a), list(fe_b)
    nd = len(a)
    if not nd or nd != len(b) or len(set(a + b)) != 2 * nd:
        raise ValueError("Fe orbital lists must be equally long, distinct and disjoint")
    if min(a + b) < 0 or max(a + b) >= n:
        raise ValueError("Fe indices outside orbital range")
    lig = sorted(set(range(n)) - set(a + b))
    mask_l = sum(3 << (2 * p) for p in lig)
    state = {}
    # Spin orbitals ordered p-alpha, p-beta, then next p. With single
    # occupancy, local spin-lowering has positive matrix elements.
    for k in range(nd + 1):
        amp = (-1.0)**(nd-k) / (math.sqrt(nd + 1) * math.comb(nd, k))
        for ups_a, ups_b in product(combinations(a, k), combinations(b, nd-k)):
            up = set(ups_a + ups_b)
            det = mask_l
            for p in a + b:
                det |= 1 << (2*p + int(p not in up))
            state[det] = amp
    return state, lig


_BYTE_POP = np.array([i.bit_count() for i in range(256)], dtype=np.uint8)


def count_bits(x):
    x = np.asarray(x, dtype=np.uint64)
    if hasattr(np, "bitwise_count"):
        return np.bitwise_count(x)
    buf = np.ascontiguousarray(x).view(np.uint8).reshape(x.shape + (8,))
    return _BYTE_POP[buf].sum(axis=-1)


def fermion_sign(det, below):
    return 1 - 2 * (count_bits(det & below).astype(np.int16) % 2)


def spin_integrals(h, eri):
    n = 2 * len(h)
    hso = np.zeros((n, n))
    hso[::2, ::2] = hso[1::2, 1::2] = h
    # g[a,b,i,j] = <a b || i j>. Direct spin block before antisymmetrizing.
    g = np.zeros((n,) * 4)
    coul = eri.transpose(0, 2, 1, 3)
    for sa, sb in product(range(2), repeat=2):
        g[sa::2, sb::2, sa::2, sb::2] = coul
    return hso, g - g.swapaxes(2, 3)


def act_on_state(state, h, eri, ecore):
    """Accumulate exact Slater-Condon terms incl. interference before norms."""
    hso, g = spin_integrals(h, eri)
    nso = len(hso)
    positions = np.arange(nso)
    bits = np.int64(1) << positions
    out_ids, out_vals = [], []

    def add(ids, vals, coeff):
        ids, vals = np.broadcast_arrays(ids, vals)
        nz = vals != 0
        if nz.any():
            out_ids.append(ids[nz].ravel())
            out_vals.append((coeff * vals[nz]).ravel())

    for d_int, coeff in state.items():
        d = np.int64(d_int)
        occ = positions[(d & bits) != 0]
        virt = positions[(d & bits) == 0]
        i, j = occ[np.triu_indices(len(occ), 1)[0]], occ[np.triu_indices(len(occ), 1)[1]]
        e = ecore + hso[occ, occ].sum() + g[i, j, i, j].sum()
        add(d, e, coeff)
        # Singles: a^dagger_a a_i.
        I, A = occ[:, None], virt[None, :]
        d_i = d ^ bits[I]
        sign = fermion_sign(d, bits[I]-1) * fermion_sign(d_i, bits[A]-1)
        singles = hso[A, I].copy()
        for o in occ:
            singles += g[A, o, I, o]
        add(d_i ^ bits[A], sign * singles, coeff)
        # Doubles: a^dagger_a a^dagger_b a_j a_i for a<b, i<j.
        vi, vj = np.triu_indices(len(virt), 1)
        A, B = virt[vi][None, :], virt[vj][None, :]
        I, J = i[:, None], j[:, None]
        d_i = d ^ bits[I]
        d_ij = d_i ^ bits[J]
        d_ijb = d_ij ^ bits[B]
        sign = (fermion_sign(d, bits[I]-1) * fermion_sign(d_i, bits[J]-1)
                * fermion_sign(d_ij, bits[B]-1) * fermion_sign(d_ijb, bits[A]-1))
        add(d_ijb ^ bits[A], sign * g[A, B, I, J], coeff)
    if not out_ids:
        return np.array([], dtype=np.int64), np.array([], dtype=float)
    ids, vals = np.concatenate(out_ids), np.concatenate(out_vals)
    order = np.argsort(ids, kind="stable")
    ids, vals = ids[order], vals[order]
    starts = np.r_[0, np.flatnonzero(ids[1:] != ids[:-1]) + 1]
    return ids[starts], np.add.reduceat(vals, starts)


def diagnose(h, eri, ecore, ne, a, b):
    state, lig = formal_singlet(len(h), a, b)
    if ne != 2 * len(lig) + len(a) + len(b):
        raise ValueError("NELEC incompatible with half-filled Fe shells and closed ligands")
    ids, vals = act_on_state(state, h, eri, ecore)
    coeffs = np.fromiter((state.get(int(i), 0.0) for i in ids), dtype=float)
    energy = float(vals @ coeffs)
    # Compute residual explicitly, including any unreturned source determinants.
    residual = vals - energy * coeffs
    missing_norm2 = sum(state[d]**2 for d in state.keys() - set(map(int, ids)))
    var = float(residual @ residual) + energy**2 * missing_norm2
    ma = sum(3 << (2*p) for p in a)
    mb = sum(3 << (2*p) for p in b)
    n_a = count_bits(ids & ma).astype(int)
    n_b = count_bits(ids & mb).astype(int)
    records = []
    for na, nb in sorted(set(zip(n_a.tolist(), n_b.tolist()))):
        sel = (n_a == na) & (n_b == nb)
        origin = (na, nb) == (len(a), len(b))
        norm_h = float(np.linalg.norm(vals[sel]))
        norm_r = math.sqrt(float(residual[sel] @ residual[sel]) +
                           (energy**2 * missing_norm2 if origin else 0.0))
        records.append(dict(N_A=na, N_B=nb, ligand_holes=2*len(lig)-(ne-na-nb),
                            H_u_norm=norm_h, residual_norm=norm_r))
    if missing_norm2 and not any((r['N_A'],r['N_B'])==(len(a),len(b)) for r in records):
        records.append(dict(N_A=len(a),N_B=len(b),ligand_holes=0,H_u_norm=0.0,
                            residual_norm=abs(energy)*math.sqrt(missing_norm2)))
    hf_norm = math.sqrt(sum(r["H_u_norm"]**2 for r in records
                            if (r["N_A"],r["N_B"]) != (len(a),len(b))))
    return dict(Fe_A_1based=[p+1 for p in a], Fe_B_1based=[p+1 for p in b],
                ligand_1based=[p+1 for p in lig], formal_singlet_terms=len(state),
                input_particle_number=ne, norm2=sum(x*x for x in state.values()),
                energy=energy, total_residual_norm=math.sqrt(var),
                outside_ionic_charge_norm=hf_norm, by_charge=records)


def brute_action(state, h, eri, core):
    """Independent small-system reference using the second-quantized definition."""
    from collections import defaultdict
    out = defaultdict(float)
    for d, c in state.items():
        out[d] += core*c
        def term(seq, weight):
            bits, sign = d, 1
            for index, create in seq:
                if bool((bits >> index) & 1) == create:
                    return
                sign *= (-1)**((bits & ((1 << index)-1)).bit_count())
                bits ^= 1 << index
            out[bits] += sign*weight*c
        for p, q in product(range(len(h)), repeat=2):
            for s in range(2):
                term([(2*q+s,False),(2*p+s,True)], h[p,q])
            for r, t in product(range(len(h)), repeat=2):
                for s, u in product(range(2), repeat=2):
                    term([(2*q+s,False),(2*t+u,False),(2*r+u,True),(2*p+s,True)],
                         0.5*eri[p,q,r,t])
    return out


def self_test():
    # Hubbard dimer: singlet spin coupling gives nonzero hopping to BOTH ionic
    # states; a triplet spin convention mistake gives zero.
    with tempfile.TemporaryDirectory() as td:
        f = Path(td)/"FCIDUMP"
        f.write_text("&FCI NORB=2,NELEC=2,MS2=0,\nORBSYM=1,1,\n&END\n"
                     "8 1 1 1 1\n8 2 2 2 2\n-1.2D+00 1 2 0 0\n0.3 0 0 0 0\n")
        h,v,ec,ne = read_fcidump(f)
        obs = diagnose(h,v,ec,ne,[0],[1])
        assert np.allclose([obs["energy"],obs["outside_ionic_charge_norm"]],
                           [0.3,2.4], rtol=0,atol=1e-12)
    rng = np.random.default_rng(917)
    n = 3
    h = rng.normal(size=(n,n)); h = (h+h.T)/2
    factors = rng.normal(size=(4,n,n)); factors = (factors+factors.swapaxes(1,2))/2
    v = np.einsum("xpq,xrs->pqrs", factors, factors)
    state, _ = formal_singlet(n,[2],[0])
    ids, vals = act_on_state(state,h,v,-0.42)
    fast = dict(zip(ids.tolist(),vals.tolist()))
    slow = brute_action(state,h,v,-0.42)
    assert all(abs(fast.get(d,0)-slow.get(d,0)) < 1e-12 for d in set(fast)|set(slow))
    # An arbitrary determinant superposition also probes unrelated relative signs.
    state = {sum(1<<p for p in xy):float(rng.normal()) for xy in combinations(range(6),3)}
    ids,vals=act_on_state(state,h,v,0.7)
    fast=dict(zip(ids.tolist(),vals.tolist())); slow=brute_action(state,h,v,0.7)
    assert all(abs(fast.get(d,0)-slow.get(d,0))<1e-11 for d in set(fast)|set(slow))
    big, _ = formal_singlet(20,list(range(5)),list(range(5,10)))
    assert len(big)==252 and abs(sum(c*c for c in big.values())-1)<1e-13
    print("PASS: FCIDUMP, Hubbard dimer H|singlet>, independent second-quantized "
          "reference for two states, Fe d5-d5 singlet normalization.")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("fcidump",nargs="?")
    parser.add_argument("--fe-a", help="comma-separated one-based Fe A orbital indices")
    parser.add_argument("--fe-b", help="comma-separated one-based Fe B orbital indices")
    parser.add_argument("--output", type=Path, help="save JSON, default stdout")
    parser.add_argument("--self-test", action="store_true")
    args=parser.parse_args()
    if args.self_test:
        self_test()
        return
    if not (args.fcidump and args.fe_a and args.fe_b):
        parser.error("provide FCIDUMP and both --fe-a and --fe-b")
    parse_orbs=lambda s: [int(p)-1 for p in s.split(",")]
    h, eri, ec, ne=read_fcidump(args.fcidump)
    result=diagnose(h,eri,ec,ne,parse_orbs(args.fe_a),parse_orbs(args.fe_b))
    result["fcidump"]=str(args.fcidump)
    content=json.dumps(result,indent=2,allow_nan=False)+"\n"
    if args.output:
        args.output.write_text(content)
    else:
        print(content,end="")


if __name__=="__main__":
    main()
